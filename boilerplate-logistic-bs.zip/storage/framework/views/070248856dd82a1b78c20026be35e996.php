<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Surat Jalan <?php echo e($order->do_number); ?></title>

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            background: #e5e7eb;
            color: #111;
        }

        .toolbar {
            padding: 14px;
            background: white;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
        }

        .btn {
            padding: 8px 14px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background: white;
            cursor: pointer;
            text-decoration: none;
            color: #111;
        }

        .btn-primary {
            background: #0d6efd;
            color: white;
            border-color: #0d6efd;
        }

        .page {
            width: 210mm;
            min-height: 297mm;
            margin: 16px auto;
            background: white;
            padding: 16mm;
            box-shadow: 0 8px 30px rgba(0,0,0,.15);
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #111;
            padding-bottom: 12px;
            margin-bottom: 20px;
        }

        h1 {
            margin: 0;
            font-size: 22px;
        }

        .meta {
            font-size: 13px;
            line-height: 1.6;
        }

        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 16px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
            margin-top: 16px;
        }

        th, td {
            border: 1px solid #111;
            padding: 7px;
        }

        th {
            background: #f3f4f6;
        }

        .signatures {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-top: 60px;
            text-align: center;
            font-size: 12px;
        }

        .signature-box {
            height: 90px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        @media print {
            @page {
                size: A4;
                margin: 0;
            }

            body {
                background: white;
            }

            .toolbar {
                display: none;
            }

            .page {
                margin: 0;
                box-shadow: none;
                width: auto;
                min-height: auto;
            }
        }
    </style>
</head>
<body>
    <div class="toolbar">
        <div><strong>Surat Jalan</strong> <?php echo e($order->do_number); ?></div>
        <div>
            <a href="<?php echo e(route('loading.index')); ?>" class="btn">Kembali</a>
            <button onclick="window.print()" class="btn btn-primary">Print</button>
        </div>
    </div>

    <div class="page">
        <div class="header">
            <h1>SURAT JALAN</h1>
            <div class="meta">Camiloplas Logistic</div>
        </div>

        <div class="grid meta">
            <div>
                <div><strong>No Surat Jalan:</strong> SJ-<?php echo e($order->do_number); ?></div>
                <div><strong>No DO:</strong> <?php echo e($order->do_number); ?></div>
                <div><strong>No SO:</strong> <?php echo e($order->so_number); ?></div>
            </div>

            <div>
                <div><strong>Tanggal:</strong> <?php echo e(\Carbon\Carbon::parse($order->loaded_at)->format('d/m/Y')); ?></div>
                <div><strong>Customer:</strong> <?php echo e($order->customer_name); ?></div>
                <div><strong>No Truck:</strong> <?php echo e($order->truck_number ?? '-'); ?></div>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th width="35">No</th>
                    <th>Barcode</th>
                    <th>Box</th>
                    <th>Item</th>
                    <th>Troli</th>
                    <th>Rak</th>
                    <th width="70">Qty</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $loadedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($item->barcode); ?></td>
                        <td><?php echo e($item->box_number); ?></td>
                        <td>
                            <?php echo e($item->item_name); ?>

                            <br>
                            <small><?php echo e($item->item_code); ?></small>
                        </td>
                        <td><?php echo e($item->trolley_code ?? '-'); ?></td>
                        <td><?php echo e($item->rack_code ?? '-'); ?></td>
                        <td><?php echo e(number_format($item->qty, 0, ',', '.')); ?> <?php echo e($item->uom); ?></td>
                    </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>

        <div class="signatures">
            <div class="signature-box">
                <div>Dibuat</div>
                <div>(__________)</div>
            </div>

            <div class="signature-box">
                <div>Warehouse</div>
                <div>(__________)</div>
            </div>

            <div class="signature-box">
                <div>Security</div>
                <div>(__________)</div>
            </div>

            <div class="signature-box">
                <div>Driver</div>
                <div>(__________)</div>
            </div>
        </div>
    </div>

    <script>
        window.addEventListener('load', () => {
            setTimeout(() => window.print(), 500);
        });
    </script>
</body>
</html>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/prints/loading-surat-jalan.blade.php ENDPATH**/ ?>