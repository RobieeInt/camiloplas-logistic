<?php
    use Illuminate\Support\Facades\Route;

    $menuService = app(\App\Services\System\MenuService::class);
    $menus = $menuService->getSidebarMenus(auth()->id());
?>

<aside class="bg-dark text-white min-vh-100" style="width: 270px;">
    <div class="p-3 border-bottom border-secondary">
        <h5 class="mb-0">Camiloplas Logistic</h5>
        <small class="text-secondary">Warehouse Flow System</small>
    </div>

    <ul class="nav flex-column p-3 gap-1">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php
                $children = $menu->children ?? [];
                $hasChildren = count($children) > 0;

                $menuUrl = '#';

                if (!empty($menu->route) && Route::has($menu->route)) {
                    $menuUrl = route($menu->route);
                }
            ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasChildren): ?>
                <li class="nav-item text-uppercase small text-secondary mt-3 mb-1">
                    <?php echo e($menu->name); ?>

                </li>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php
                        $childUrl = '#';

                        if (!empty($child->route) && Route::has($child->route)) {
                            $childUrl = route($child->route);
                        }
                    ?>

                    <li class="nav-item">
                        <a href="<?php echo e($childUrl); ?>" class="nav-link text-white rounded">
                            <i class="<?php echo e($child->icon ?: 'bi bi-circle'); ?> me-2"></i>
                            <?php echo e($child->name); ?>

                        </a>
                    </li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php else: ?>
                <li class="nav-item">
                    <a href="<?php echo e($menuUrl); ?>" class="nav-link text-white rounded">
                        <i class="<?php echo e($menu->icon ?: 'bi bi-circle'); ?> me-2"></i>
                        <?php echo e($menu->name); ?>

                    </a>
                </li>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </ul>
</aside>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>