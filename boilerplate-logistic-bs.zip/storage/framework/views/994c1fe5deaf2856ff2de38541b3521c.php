<nav class="navbar navbar-expand-lg bg-white border-bottom px-4">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h6">Logistic Module</span>

        <div class="dropdown">
            <button class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                <?php echo e(auth()->user()->name); ?>

            </button>

            <ul class="dropdown-menu dropdown-menu-end">
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item" type="submit">Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>