<div>
    <style>
        @media (max-width: 767.98px) {
            .fgd-summary .fs-2 {
                font-size: 1.5rem !important;
            }

            .fgd-actions {
                display: grid !important;
                grid-template-columns: 1fr;
                gap: .5rem;
            }

            .fgd-table th,
            .fgd-table td {
                font-size: .85rem;
                white-space: nowrap;
            }
        }
    </style>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Finish Goods Warehouse</h4>
            <div class="text-muted">
                Validasi troli dari Temporary Warehouse dan simpan ke RAK FGW.
            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success rounded-3 border-0 shadow-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger rounded-3 border-0 shadow-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="row g-3 mb-4 fgd-summary">
        <div class="col-6 col-md-6">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Menunggu Validasi</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->waiting_validation); ?></div>
                    <div class="small text-muted">Troli dari Temporary Warehouse</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Diterima Hari Ini</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->received_today); ?></div>
                    <div class="small text-muted">Troli masuk FGW</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Scan Troli</h5>
            <div class="text-muted small">
                Scan barcode / QR troli dari Temporary Warehouse.
            </div>
        </div>

        <div class="card-body px-4 pb-4">
            <form wire:submit.prevent="scanTrolley">
                <div class="row g-3 align-items-end">
                    <div class="col-lg-10">
                        <label class="form-label fw-semibold">Barcode Troli</label>

                        <input
                            type="text"
                            id="fgwTrolleyInput"
                            wire:model.defer="trolleyBarcode"
                            class="form-control form-control-lg rounded-3"
                            placeholder="Scan barcode troli"
                            autocomplete="off"
                            autofocus
                        >
                    </div>

                    <div class="col-lg-2 d-grid">
                        <button class="btn btn-primary btn-lg rounded-3">
                            <i class="bi bi-upc-scan me-1"></i>
                            Scan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Data Troli Masuk FGW</h5>
            <div class="text-muted small">
                Troli yang sudah diterima FGW beserta lokasi raknya.
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 fgd-table">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Troli</th>
                        <th>Barcode</th>
                        <th>RAK</th>
                        <th>Isi</th>
                        <th>Diterima</th>
                        <th>User</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentTrolleys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trolley): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-semibold"><?php echo e($trolley->trolley_code); ?></div>
                                <span class="badge rounded-pill text-bg-success"><?php echo e($trolley->status); ?></span>
                            </td>
                            <td><code><?php echo e($trolley->barcode); ?></code></td>
                            <td>
                                <div class="fw-semibold"><?php echo e($trolley->rack_code ?? '-'); ?></div>
                                <small class="text-muted"><?php echo e($trolley->rack_name ?? '-'); ?></small>
                            </td>
                            <td><?php echo e($trolley->total_items); ?> dus</td>
                            <td>
                                <?php echo e($trolley->received_fgw_at ? \Carbon\Carbon::parse($trolley->received_fgw_at)->format('d M Y H:i') : '-'); ?>

                            </td>
                            <td><?php echo e($trolley->received_by_name ?? '-'); ?></td>
                            <td class="text-end pe-4">
                                <button
                                    type="button"
                                    class="btn btn-sm btn-light border rounded-3"
                                    wire:click="openReceivedDetail(<?php echo e($trolley->id); ?>)"
                                >
                                    <i class="bi bi-list-check me-1"></i>
                                    Detail
                                </button>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                Belum ada troli masuk FGW.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showReceiveModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showReceiveModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Validasi Dus FGW</h5>
                        <div class="text-muted small">
                            Semua dus wajib discan ulang, lalu pilih rak.
                        </div>
                    </div>

                    <button type="button" class="btn-close" wire:click="closeModal"></button>
                </div>

                <form wire:submit.prevent="validateDus">
                    <div class="modal-body">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_success')): ?>
                            <div class="alert alert-success rounded-3 border-0">
                                <?php echo e(session('scan_success')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_error')): ?>
                            <div class="alert alert-danger rounded-3 border-0">
                                <?php echo e(session('scan_error')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="border rounded-4 p-3 mb-3 bg-light">
                            <div class="row g-3">
                                <div class="col-lg-4">
                                    <div class="small text-muted">Troli</div>
                                    <div class="fw-bold fs-5"><?php echo e($selectedTrolley->trolley_code ?? '-'); ?></div>
                                    <code><?php echo e($selectedTrolley->barcode ?? '-'); ?></code>
                                </div>

                                <div class="col-lg-4">
                                    <label class="form-label fw-semibold">Pilih RAK FGW</label>
                                    <select wire:model="selectedRackId" class="form-select rounded-3">
                                        <option value="">Pilih RAK</option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <option value="<?php echo e($rack->id); ?>">
                                                <?php echo e($rack->rack_code); ?> - <?php echo e($rack->rack_name); ?>

                                            </option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </select>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['selectedRackId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <div class="col-lg-4">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span>Progress Validasi</span>
                                        <span><?php echo e($totalValidated); ?>/<?php echo e(count($trolleyItems)); ?></span>
                                    </div>

                                    <div class="progress" style="height: 10px;">
                                        <div
                                            class="progress-bar bg-success"
                                            style="width: <?php echo e(count($trolleyItems) > 0 ? ($totalValidated / count($trolleyItems)) * 100 : 0); ?>%"
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Barcode Dus</label>

                            <input
                                type="text"
                                id="fgwPackingInput"
                                wire:model.defer="packingBarcode"
                                class="form-control form-control-lg rounded-3 text-center fw-bold"
                                placeholder="Scan barcode dus"
                                autocomplete="off"
                            >
                        </div>

                        <div class="d-flex justify-content-end mb-3">
                            <button
                                type="button"
                                class="btn btn-success rounded-3 px-4"
                                wire:click="completeReceiving"
                                <?php if($totalValidated < count($trolleyItems) || count($trolleyItems) === 0): echo 'disabled'; endif; ?>
                            >
                                <i class="bi bi-check-circle me-1"></i>
                                Complete Receive
                            </button>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Barcode</th>
                                        <th>Box</th>
                                        <th>Item</th>
                                        <th>SPK</th>
                                        <th>Qty</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                        $waitingItems = collect($trolleyItems)
                                            ->filter(fn ($item) => !in_array($item->barcode, $validatedItems))
                                            ->values();

                                        $validatedItemRows = collect($trolleyItems)
                                            ->filter(fn ($item) => in_array($item->barcode, $validatedItems))
                                            ->values();

                                        $sortedTrolleyItems = $waitingItems->concat($validatedItemRows);
                                    ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $sortedTrolleyItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <?php
                                            $isValidated = in_array($item->barcode, $validatedItems);
                                        ?>

                                        <tr class="<?php echo e($isValidated ? 'table-success' : ''); ?>">
                                            <td><code><?php echo e($item->barcode); ?></code></td>
                                            <td><?php echo e($item->box_number); ?></td>
                                            <td>
                                                <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                                <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                            </td>
                                            <td><?php echo e($item->spk_number); ?></td>
                                            <td><?php echo e(number_format($item->qty, 0, ',', '.')); ?> <?php echo e($item->uom); ?></td>
                                            <td>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isValidated): ?>
                                                    <span class="badge text-bg-success rounded-pill">VALIDATED</span>
                                                <?php else: ?>
                                                    <span class="badge text-bg-light border rounded-pill">WAITING</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showReceivedDetailModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showReceivedDetailModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Detail Troli Masuk FGW</h5>
                        <div class="text-muted small">
                            Detail barang yang sudah diterima FGW.
                        </div>
                    </div>

                    <button type="button" class="btn-close" wire:click="closeReceivedDetail"></button>
                </div>

                <div class="modal-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($receivedDetailTrolley): ?>
                        <div class="border rounded-4 p-3 mb-3 bg-light">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="small text-muted">Troli</div>
                                    <div class="fw-bold"><?php echo e($receivedDetailTrolley->trolley_code); ?></div>
                                    <code><?php echo e($receivedDetailTrolley->barcode); ?></code>
                                </div>
                                <div class="col-md-3">
                                    <div class="small text-muted">RAK</div>
                                    <div class="fw-bold"><?php echo e($receivedDetailTrolley->rack_code ?? '-'); ?></div>
                                    <small><?php echo e($receivedDetailTrolley->rack_name ?? '-'); ?></small>
                                </div>
                                <div class="col-md-3">
                                    <div class="small text-muted">Diterima</div>
                                    <div>
                                        <?php echo e($receivedDetailTrolley->received_fgw_at ? \Carbon\Carbon::parse($receivedDetailTrolley->received_fgw_at)->format('d M Y H:i') : '-'); ?>

                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="small text-muted">Total Dus</div>
                                    <div class="fw-bold"><?php echo e($receivedDetailTrolley->total_items); ?> dus</div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Barcode</th>
                                    <th>Box</th>
                                    <th>Item</th>
                                    <th>SPK</th>
                                    <th>Qty</th>
                                    <th>Status</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $receivedDetailItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <tr>
                                        <td><code><?php echo e($item->barcode); ?></code></td>
                                        <td><?php echo e($item->box_number); ?></td>
                                        <td>
                                            <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                            <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                        </td>
                                        <td><?php echo e($item->spk_number); ?></td>
                                        <td><?php echo e(number_format($item->qty, 0, ',', '.')); ?> <?php echo e($item->uom); ?></td>
                                        <td>
                                            <span class="badge rounded-pill text-bg-success"><?php echo e($item->status); ?></span>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-5">
                                            Detail kosong.
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="modal-footer border-0 pt-0">
                    <button type="button" wire:click="closeReceivedDetail" class="btn btn-light border rounded-3 px-4">
                        Tutup
                    </button>
                </div>
            </div>
        </div>
    </div>

        <?php
        $__scriptKey = '1373868105-0';
        ob_start();
    ?>
    <script>
        function focusFgwPacking() {
            setTimeout(() => {
                const input = document.getElementById('fgwPackingInput');
                if (input) {
                    input.value = '';
                    input.focus();
                    input.select();
                }
            }, 150);
        }

        function focusFgwTrolley() {
            setTimeout(() => {
                const input = document.getElementById('fgwTrolleyInput');
                if (input) {
                    input.value = '';
                    input.focus();
                    input.select();
                }
            }, 150);
        }

        Livewire.on('fgw-scan-opened', () => {
            focusFgwPacking();
        });

        Livewire.on('fgw-ready-again', () => {
            focusFgwPacking();
        });

        Livewire.on('fgw-modal-closed', () => {
            focusFgwTrolley();
        });

        Livewire.on('fgw-focus-trolley', () => {
            focusFgwTrolley();
        });
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/livewire/pages/fgd/index.blade.php ENDPATH**/ ?>