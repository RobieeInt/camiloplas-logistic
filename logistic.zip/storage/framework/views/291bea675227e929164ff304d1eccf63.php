<div>
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1">Log Scan Dus</h4>
            <div class="text-muted">Scan barcode untuk lihat detail produksi, atau cari di tabel di bawah.</div>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body">
            <form wire:submit.prevent="scan" class="d-flex gap-3 align-items-end flex-wrap">
                <div class="flex-grow-1">
                    <label class="form-label fw-semibold mb-1">Scan / Ketik Barcode Dus</label>
                    <input
                        type="text"
                        id="scanLogInput"
                        wire:model.defer="scanBarcode"
                        class="form-control form-control-lg rounded-3 <?php $__errorArgs = ['scanBarcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Scan barcode atau ketik nomor barcode..."
                        autocomplete="off"
                    >
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['scanBarcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div>
                    <button type="submit" class="btn btn-primary btn-lg rounded-3 px-4">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>
                </div>
            </form>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_error')): ?>
                <div class="alert alert-danger border-0 rounded-3 mt-3 mb-0">
                    <i class="bi bi-exclamation-triangle me-1"></i> <?php echo e(session('scan_error')); ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-3"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-2">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body py-3">
                    <div class="text-muted small">Total Dus</div>
                    <div class="fs-4 fw-bold"><?php echo e(number_format($summary->total)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-2">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body py-3">
                    <div class="text-muted small">Belum Scan TW</div>
                    <div class="fs-4 fw-bold text-warning"><?php echo e(number_format($summary->total_printed)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-2">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body py-3">
                    <div class="text-muted small">Scan TW</div>
                    <div class="fs-4 fw-bold text-success"><?php echo e(number_format($summary->total_tw_scanned)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-2">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body py-3">
                    <div class="text-muted small">Dalam Troli</div>
                    <div class="fs-4 fw-bold text-primary"><?php echo e(number_format($summary->total_in_trolley)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-2">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body py-3">
                    <div class="text-muted small">Di FGW</div>
                    <div class="fs-4 fw-bold text-info"><?php echo e(number_format($summary->total_fgw)); ?></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-2">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body py-3">
                    <div class="text-muted small">Loaded</div>
                    <div class="fs-4 fw-bold text-dark"><?php echo e(number_format($summary->total_loaded)); ?></div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="p-3 border-bottom bg-white">
                <div class="row g-2 align-items-center">
                    <div class="col-md-4">
                        <div class="input-group">
                            <span class="input-group-text bg-light border-0"><i class="bi bi-search"></i></span>
                            <input
                                type="text"
                                wire:model.live.debounce.400ms="search"
                                class="form-control border-0 bg-light"
                                placeholder="Barcode, box, SPK, item, batch..."
                            >
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <select wire:model.live="filterStatus" class="form-select border-0 bg-light">
                            <option value="">Semua Status</option>
                            <option value="PRINTED">PRINTED</option>
                            <option value="TW_SCANNED">TW SCANNED</option>
                            <option value="SCANNED_TO_TROLLEY">IN TROLLEY</option>
                            <option value="SENT_FGW">SENT FGW</option>
                            <option value="RECEIVED_FGW">RECEIVED FGW</option>
                            <option value="LOADED">LOADED</option>
                        </select>
                    </div>
                    <div class="col-6 col-md-2">
                        <select wire:model.live="filterDate" class="form-select border-0 bg-light">
                            <option value="">Semua Tanggal</option>
                            <option value="today">Hari Ini</option>
                            <option value="week">7 Hari Terakhir</option>
                            <option value="month">30 Hari Terakhir</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-2 align-items-center">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search || $filterStatus || $filterDate): ?>
                            <button wire:click="resetFilters" class="btn btn-sm btn-light border rounded-3">
                                <i class="bi bi-x-circle me-1"></i> Reset
                            </button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <span class="text-muted small ms-auto"><?php echo e(number_format($logs->total())); ?> data</span>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 small">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Box / Barcode</th>
                            <th>Item</th>
                            <th>SPK</th>
                            <th>Batch / LOT</th>
                            <th>Produksi</th>
                            <th>QC</th>
                            <th>Status</th>
                            <th>Print</th>
                            <th>TW Scan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-semibold"><?php echo e($log->box_number); ?></div>
                                    <code class="text-muted"><?php echo e($log->barcode); ?></code>
                                    <div class="text-muted"><?php echo e(number_format($log->qty)); ?> <?php echo e($log->uom); ?></div>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($log->item_name); ?></div>
                                    <small class="text-muted"><?php echo e($log->item_code); ?></small>
                                </td>
                                <td>
                                    <div><?php echo e($log->spk_number); ?></div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->factory): ?>
                                        <small class="text-muted"><?php echo e($log->factory); ?></small>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->batch_number): ?>
                                        <div class="fw-semibold text-primary small"><?php echo e($log->batch_number); ?></div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->lot_number): ?>
                                            <small class="text-muted">LOT: <?php echo e($log->lot_number); ?></small>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->berat): ?>
                                            <div class="text-muted small"><?php echo e($log->berat); ?> kg</div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->operator): ?>
                                        <div><?php echo e($log->operator); ?></div>
                                        <small class="text-muted"><?php echo e($log->mesin_kode); ?> · <?php echo e($log->shift); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($log->qc_operator ?? '—'); ?>

                                </td>
                                <td>
                                    <?php
                                        [$bg, $extra, $label] = match($log->status) {
                                            'PRINTED'            => ['warning',   'text-dark', 'PRINTED'],
                                            'TW_SCANNED'         => ['success',   '',          'TW SCANNED'],
                                            'SCANNED_TO_TROLLEY' => ['primary',   '',          'IN TROLLEY'],
                                            'SENT_FGW'           => ['info',      'text-dark', 'SENT FGW'],
                                            'RECEIVED_FGW'       => ['secondary', '',          'RECEIVED FGW'],
                                            'LOADED'             => ['dark',      '',          'LOADED'],
                                            default              => ['secondary', '',          $log->status],
                                        };
                                    ?>
                                    <span class="badge rounded-pill text-bg-<?php echo e($bg); ?> <?php echo e($extra); ?>"><?php echo e($label); ?></span>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->printed_at): ?>
                                        <div class="small"><?php echo e(\Carbon\Carbon::parse($log->printed_at)->format('d/m/Y H:i')); ?></div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->printed_by_name): ?>
                                            <small class="text-muted"><?php echo e($log->printed_by_name); ?></small>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->prod_scanned_at): ?>
                                        <div class="small fw-semibold text-success"><?php echo e(\Carbon\Carbon::parse($log->prod_scanned_at)->format('d/m/Y H:i')); ?></div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->tw_scanned_by_name): ?>
                                            <small class="text-muted"><?php echo e($log->tw_scanned_by_name); ?></small>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-5">
                                    <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                    Tidak ada data scan ditemukan.
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="p-3 border-top bg-white">
                <?php echo e($logs->links()); ?>

            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showDetailModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showDetailModal): ?> background: rgba(15,23,42,.55); overflow: hidden; <?php else: ?> display:none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content border-0 shadow rounded-4" style="max-height: 90vh; display: flex; flex-direction: column; overflow: hidden;">

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($detail): ?>
                <?php
                    $pu      = $detail['packing_unit'];
                    $batches = $detail['batches'] ?? [];
                    $spk     = $detail['spk'];
                    $hasBom  = !empty($detail['bom_items']);
                    $hasRuns = !empty($detail['runs']);

                    $statusBadge = match($pu['status']) {
                        'PRINTED'            => ['warning',   'text-dark', 'PRINTED'],
                        'TW_SCANNED'         => ['success',   '',          'TW SCANNED'],
                        'SCANNED_TO_TROLLEY' => ['primary',   '',          'IN TROLLEY'],
                        'SENT_FGW'           => ['info',      'text-dark', 'SENT FGW'],
                        'RECEIVED_FGW'       => ['secondary', '',          'RECEIVED FGW'],
                        'LOADED'             => ['dark',      '',          'LOADED'],
                        default              => ['secondary', '',          $pu['status']],
                    };
                ?>

                <div class="modal-header border-0 pb-1">
                    <div>
                        <div class="d-flex align-items-center gap-2">
                            <h5 class="modal-title fw-bold mb-0"><?php echo e($pu['box_number']); ?></h5>
                            <span class="badge text-bg-<?php echo e($statusBadge[0]); ?> <?php echo e($statusBadge[1]); ?> rounded-pill"><?php echo e($statusBadge[2]); ?></span>
                        </div>
                        <div class="text-muted small mt-1">
                            <code><?php echo e($pu['barcode']); ?></code>
                            &nbsp;·&nbsp; <?php echo e($pu['item_name']); ?> (<?php echo e($pu['item_code']); ?>)
                            &nbsp;·&nbsp; <?php echo e(number_format($pu['qty'])); ?> <?php echo e($pu['uom']); ?>

                        </div>
                    </div>
                    <button type="button" class="btn-close" wire:click="closeDetailModal"></button>
                </div>

                <div class="modal-body pt-2" style="overflow-y: auto; flex: 1 1 auto;">
                    <div class="row g-3">

                        
                        <div class="col-md-6">
                            <div class="card border rounded-3 h-100">
                                <div class="card-header bg-transparent border-bottom py-2 fw-semibold small text-muted text-uppercase d-flex align-items-center gap-2">
                                    <span><i class="bi bi-boxes me-1"></i> Batch & Produksi</span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($batches)): ?>
                                        <span class="badge text-bg-primary rounded-pill fw-normal" style="font-size:.7rem"><?php echo e(count($batches)); ?></span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($detail['batch_via_spk']): ?>
                                        <span class="badge text-bg-secondary rounded-pill fw-normal" style="font-size:.7rem">via SPK</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <div class="card-body py-3" x-data="{ open: false }">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($batches)): ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bIdx => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bIdx === 0): ?>
                                                <dl class="row mb-0 small">
                                                    <dt class="col-5 text-muted">Batch</dt>
                                                    <dd class="col-7 fw-semibold text-primary mb-1"><?php echo e($b['batch_number'] ?? '—'); ?></dd>

                                                    <dt class="col-5 text-muted">LOT</dt>
                                                    <dd class="col-7 mb-1"><?php echo e($b['lot_number'] ?? '—'); ?></dd>

                                                    <dt class="col-5 text-muted">Berat</dt>
                                                    <dd class="col-7 mb-1"><?php echo e($b['berat'] ? number_format($b['berat'], 2) . ' kg' : '—'); ?></dd>

                                                    <dt class="col-5 text-muted">QC Inspector</dt>
                                                    <dd class="col-7 mb-1"><?php echo e($b['qc_operator'] ?? '—'); ?></dd>

                                                    <dt class="col-5 text-muted">Status Batch</dt>
                                                    <dd class="col-7 mb-1">
                                                        <span class="badge text-bg-<?php echo e(($b['status'] ?? '') === 'picked_up' ? 'success' : 'secondary'); ?> rounded-pill">
                                                            <?php echo e(strtoupper($b['status'] ?? '—')); ?>

                                                        </span>
                                                    </dd>

                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($b['qc_printed_at'])): ?>
                                                        <dt class="col-5 text-muted">QC Printed</dt>
                                                        <dd class="col-7 mb-1"><?php echo e(\Carbon\Carbon::parse($b['qc_printed_at'])->format('d/m/Y H:i')); ?></dd>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($b['operator']) || !empty($b['mesin_kode']) || !empty($b['shift'])): ?>
                                                        <dt class="col-5 text-muted">Operator</dt>
                                                        <dd class="col-7 mb-1"><?php echo e($b['operator'] ?? '—'); ?></dd>

                                                        <dt class="col-5 text-muted">Mesin</dt>
                                                        <dd class="col-7 mb-1"><?php echo e($b['mesin_kode'] ?? '—'); ?></dd>

                                                        <dt class="col-5 text-muted">Shift</dt>
                                                        <dd class="col-7 mb-0"><?php echo e($b['shift'] ?? '—'); ?></dd>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </dl>
                                            <?php else: ?>
                                                <div x-show="open" style="display:none">
                                                    <hr class="my-2">
                                                    <dl class="row mb-0 small">
                                                        <dt class="col-5 text-muted">Batch</dt>
                                                        <dd class="col-7 fw-semibold text-primary mb-1"><?php echo e($b['batch_number'] ?? '—'); ?></dd>

                                                        <dt class="col-5 text-muted">LOT</dt>
                                                        <dd class="col-7 mb-1"><?php echo e($b['lot_number'] ?? '—'); ?></dd>

                                                        <dt class="col-5 text-muted">Berat</dt>
                                                        <dd class="col-7 mb-1"><?php echo e($b['berat'] ? number_format($b['berat'], 2) . ' kg' : '—'); ?></dd>

                                                        <dt class="col-5 text-muted">QC Inspector</dt>
                                                        <dd class="col-7 mb-1"><?php echo e($b['qc_operator'] ?? '—'); ?></dd>

                                                        <dt class="col-5 text-muted">Status Batch</dt>
                                                        <dd class="col-7 mb-1">
                                                            <span class="badge text-bg-<?php echo e(($b['status'] ?? '') === 'picked_up' ? 'success' : 'secondary'); ?> rounded-pill">
                                                                <?php echo e(strtoupper($b['status'] ?? '—')); ?>

                                                            </span>
                                                        </dd>

                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($b['qc_printed_at'])): ?>
                                                            <dt class="col-5 text-muted">QC Printed</dt>
                                                            <dd class="col-7 mb-1"><?php echo e(\Carbon\Carbon::parse($b['qc_printed_at'])->format('d/m/Y H:i')); ?></dd>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($b['operator']) || !empty($b['mesin_kode']) || !empty($b['shift'])): ?>
                                                            <dt class="col-5 text-muted">Operator</dt>
                                                            <dd class="col-7 mb-1"><?php echo e($b['operator'] ?? '—'); ?></dd>

                                                            <dt class="col-5 text-muted">Mesin</dt>
                                                            <dd class="col-7 mb-1"><?php echo e($b['mesin_kode'] ?? '—'); ?></dd>

                                                            <dt class="col-5 text-muted">Shift</dt>
                                                            <dd class="col-7 mb-0"><?php echo e($b['shift'] ?? '—'); ?></dd>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </dl>
                                                </div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($batches) > 1): ?>
                                            <div class="mt-3">
                                                <button
                                                    type="button"
                                                    x-on:click="open = !open"
                                                    class="btn btn-sm btn-outline-secondary rounded-3 w-100"
                                                >
                                                    <span x-show="!open"><i class="bi bi-chevron-down me-1"></i> Lihat semua <?php echo e(count($batches)); ?> batch</span>
                                                    <span x-show="open" style="display:none"><i class="bi bi-chevron-up me-1"></i> Sembunyikan batch lainnya</span>
                                                </button>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <div class="text-muted small py-2">
                                            <i class="bi bi-info-circle me-1"></i>
                                            Belum ada data batch untuk SPK ini di <code>batch_pickup_log</code>.
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="card border rounded-3 h-100">
                                <div class="card-header bg-transparent border-bottom py-2 fw-semibold small text-muted text-uppercase">
                                    <i class="bi bi-file-earmark-text me-1"></i> SPK Produksi
                                </div>
                                <div class="card-body py-3">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spk): ?>
                                        <dl class="row mb-0 small">
                                            <dt class="col-5 text-muted">SPK Number</dt>
                                            <dd class="col-7 fw-semibold mb-1"><?php echo e($spk['spk_number']); ?></dd>

                                            <dt class="col-5 text-muted">Type</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['type'] ?? '—'); ?></dd>

                                            <dt class="col-5 text-muted">Pabrik</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['factory'] ?? '—'); ?></dd>

                                            <dt class="col-5 text-muted">Departemen</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['department'] ?? '—'); ?></dd>

                                            <dt class="col-5 text-muted">Produk</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['product'] ?? '—'); ?></dd>

                                            <dt class="col-5 text-muted">Qty SPK</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['qty'] ? number_format($spk['qty']) : '—'); ?></dd>

                                            <dt class="col-5 text-muted">Mesin</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['mesin'] ?? '—'); ?></dd>

                                            <dt class="col-5 text-muted">Ref SO</dt>
                                            <dd class="col-7 mb-1"><?php echo e($spk['ref_so'] ?? '—'); ?></dd>

                                            <dt class="col-5 text-muted">Status</dt>
                                            <dd class="col-7 mb-1">
                                                <span class="badge text-bg-<?php echo e($spk['status'] === 'Selesai' ? 'success' : 'warning'); ?> rounded-pill text-dark">
                                                    <?php echo e($spk['status'] ?? '—'); ?>

                                                </span>
                                            </dd>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spk['delivery_date']): ?>
                                                <dt class="col-5 text-muted">Delivery</dt>
                                                <dd class="col-7 mb-0"><?php echo e(\Carbon\Carbon::parse($spk['delivery_date'])->format('d/m/Y')); ?></dd>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </dl>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasBom): ?>
                                            <div class="mt-3">
                                                <button
                                                    type="button"
                                                    wire:click="openBomModal"
                                                    class="btn btn-sm btn-outline-primary rounded-3"
                                                >
                                                    <i class="bi bi-list-ul me-1"></i>
                                                    Lihat BOM Items (<?php echo e(count($detail['bom_items'])); ?>)
                                                </button>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <div class="text-muted small py-2">
                                            <i class="bi bi-info-circle me-1"></i>
                                            Data SPK tidak ditemukan.
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        
                        <?php
                            $lg   = $detail['logistics'] ?? [];
                            $stat = $pu['status'];
                            $steps = [
                                'PRINTED'            => 1,
                                'TW_SCANNED'         => 2,
                                'SCANNED_TO_TROLLEY' => 3,
                                'SENT_FGW'           => 4,
                                'RECEIVED_FGW'       => 5,
                                'LOADED'             => 6,
                            ];
                            $currentStep = $steps[$stat] ?? 0;
                        ?>
                        <div class="col-12">
                            <div class="card border rounded-3">
                                <div class="card-header bg-transparent border-bottom py-2 fw-semibold small text-muted text-uppercase">
                                    <i class="bi bi-signpost-split me-1"></i> Alur Scan & Pengiriman
                                </div>
                                <div class="card-body py-3">
                                    <div class="row g-2 align-items-stretch">

                                        
                                        <div class="col-6 col-md-4 col-lg-2">
                                            <div class="border rounded-3 p-2 h-100 <?php echo e($currentStep >= 1 ? 'border-success bg-success bg-opacity-10' : 'bg-light text-muted'); ?>">
                                                <div class="fw-semibold small mb-1 <?php echo e($currentStep >= 1 ? 'text-success' : 'text-muted'); ?>">
                                                    <i class="bi bi-printer me-1"></i> Print
                                                </div>
                                                <div class="small">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['printed_by'])): ?>
                                                        <div class="text-muted" style="font-size:.75rem">Oleh</div>
                                                        <div class="fw-semibold"><?php echo e($lg['printed_by']); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($pu['printed_at'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.72rem"><?php echo e(\Carbon\Carbon::parse($pu['printed_at'])->format('d/m/Y H:i')); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($lg['printed_by']) && empty($pu['printed_at'])): ?>
                                                        <span class="text-muted" style="font-size:.75rem">—</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-6 col-md-4 col-lg-2">
                                            <div class="border rounded-3 p-2 h-100 <?php echo e($currentStep >= 2 ? 'border-success bg-success bg-opacity-10' : 'bg-light'); ?>">
                                                <div class="fw-semibold small mb-1 <?php echo e($currentStep >= 2 ? 'text-success' : 'text-muted'); ?>">
                                                    <i class="bi bi-upc-scan me-1"></i> TW Scan
                                                </div>
                                                <div class="small">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['tw_scanned_by'])): ?>
                                                        <div class="text-muted" style="font-size:.75rem">Oleh</div>
                                                        <div class="fw-semibold"><?php echo e($lg['tw_scanned_by']); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['tw_scanned_at'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.72rem"><?php echo e(\Carbon\Carbon::parse($lg['tw_scanned_at'])->format('d/m/Y H:i')); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($lg['tw_scanned_by']) && empty($lg['tw_scanned_at'])): ?>
                                                        <span class="text-muted" style="font-size:.75rem">Belum</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-6 col-md-4 col-lg-2">
                                            <div class="border rounded-3 p-2 h-100 <?php echo e($currentStep >= 3 ? 'border-success bg-success bg-opacity-10' : 'bg-light'); ?>">
                                                <div class="fw-semibold small mb-1 <?php echo e($currentStep >= 3 ? 'text-success' : 'text-muted'); ?>">
                                                    <i class="bi bi-cart-check me-1"></i> TW QC → Troli
                                                </div>
                                                <div class="small">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['trolley_code'])): ?>
                                                        <div class="text-muted" style="font-size:.75rem">Troli</div>
                                                        <div class="fw-semibold"><?php echo e($lg['trolley_code']); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['trolley_scanned_by'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.75rem">Oleh</div>
                                                        <div><?php echo e($lg['trolley_scanned_by']); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['trolley_scanned_at'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.72rem"><?php echo e(\Carbon\Carbon::parse($lg['trolley_scanned_at'])->format('d/m/Y H:i')); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($lg['trolley_code'])): ?>
                                                        <span class="text-muted" style="font-size:.75rem">Belum</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-6 col-md-4 col-lg-2">
                                            <div class="border rounded-3 p-2 h-100 <?php echo e($currentStep >= 5 ? 'border-success bg-success bg-opacity-10' : 'bg-light'); ?>">
                                                <div class="fw-semibold small mb-1 <?php echo e($currentStep >= 5 ? 'text-success' : 'text-muted'); ?>">
                                                    <i class="bi bi-building me-1"></i> FGW
                                                </div>
                                                <div class="small">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['rack_code'])): ?>
                                                        <div class="text-muted" style="font-size:.75rem">Rak</div>
                                                        <div class="fw-semibold"><?php echo e($lg['rack_code']); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['rack_name'])): ?> <span class="text-muted fw-normal">· <?php echo e($lg['rack_name']); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['fgw_received_by'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.75rem">Diterima</div>
                                                        <div><?php echo e($lg['fgw_received_by']); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['received_fgw_at'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.72rem"><?php echo e(\Carbon\Carbon::parse($lg['received_fgw_at'])->format('d/m/Y H:i')); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($lg['rack_code']) && empty($lg['fgw_received_by'])): ?>
                                                        <span class="text-muted" style="font-size:.75rem">Belum</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-6 col-md-4 col-lg-2">
                                            <div class="border rounded-3 p-2 h-100 <?php echo e($currentStep >= 6 ? 'border-success bg-success bg-opacity-10' : 'bg-light'); ?>">
                                                <div class="fw-semibold small mb-1 <?php echo e($currentStep >= 6 ? 'text-success' : 'text-muted'); ?>">
                                                    <i class="bi bi-truck me-1"></i> Loading
                                                </div>
                                                <div class="small">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['loaded_by'])): ?>
                                                        <div class="text-muted" style="font-size:.75rem">Oleh</div>
                                                        <div class="fw-semibold"><?php echo e($lg['loaded_by']); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['loaded_at'])): ?>
                                                        <div class="text-muted mt-1" style="font-size:.72rem"><?php echo e(\Carbon\Carbon::parse($lg['loaded_at'])->format('d/m/Y H:i')); ?></div>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($lg['loaded_by'])): ?>
                                                        <span class="text-muted" style="font-size:.75rem">Belum</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="col-6 col-md-4 col-lg-2">
                                            <div class="border rounded-3 p-2 h-100 <?php echo e(!empty($lg['do_number']) ? 'border-primary bg-primary bg-opacity-10' : 'bg-light'); ?>">
                                                <div class="fw-semibold small mb-1 <?php echo e(!empty($lg['do_number']) ? 'text-primary' : 'text-muted'); ?>">
                                                    <i class="bi bi-file-earmark-text me-1"></i> DO & Surat Jalan
                                                </div>
                                                <div class="small">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['do_number'])): ?>
                                                        <div class="text-muted" style="font-size:.75rem">No. DO</div>
                                                        <div class="fw-semibold"><?php echo e($lg['do_number']); ?></div>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['customer_name'])): ?>
                                                            <div class="text-muted mt-1" style="font-size:.75rem">Customer</div>
                                                            <div><?php echo e($lg['customer_name']); ?></div>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['customer_address'])): ?>
                                                            <div class="text-muted" style="font-size:.72rem"><?php echo e($lg['customer_address']); ?></div>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['truck_number'])): ?>
                                                            <div class="text-muted mt-1" style="font-size:.75rem">Kendaraan</div>
                                                            <div><?php echo e($lg['truck_number']); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['driver_name'])): ?> · <?php echo e($lg['driver_name']); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($lg['surat_jalan_first_printed_at'])): ?>
                                                            <div class="text-muted mt-1" style="font-size:.72rem">
                                                                <i class="bi bi-check-circle-fill text-success me-1"></i>
                                                                Surat jalan dicetak <?php echo e(\Carbon\Carbon::parse($lg['surat_jalan_first_printed_at'])->format('d/m/Y H:i')); ?>

                                                            </div>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="text-muted" style="font-size:.75rem">Belum</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasRuns): ?>
                        <div class="col-12">
                            <div class="card border rounded-3">
                                <div class="card-header bg-transparent border-bottom py-2 fw-semibold small text-muted text-uppercase">
                                    <i class="bi bi-play-circle me-1"></i> Production Runs (<?php echo e(count($detail['runs'])); ?>)
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle mb-0 small">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="ps-3">Run Number</th>
                                                <th>Mesin</th>
                                                <th>Operator</th>
                                                <th>Pabrik</th>
                                                <th class="text-end">Qty Target</th>
                                                <th class="text-end">Qty OK</th>
                                                <th class="text-end">Reject</th>
                                                <th>Status</th>
                                                <th>Mulai</th>
                                                <th>Selesai</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $detail['runs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <tr>
                                                <td class="ps-3 fw-semibold"><?php echo e($run['run_number']); ?></td>
                                                <td>
                                                    <div><?php echo e($run['mesin_kode']); ?></div>
                                                    <small class="text-muted"><?php echo e($run['mesin_nama']); ?></small>
                                                </td>
                                                <td><?php echo e($run['operator']); ?></td>
                                                <td><?php echo e($run['factory']); ?></td>
                                                <td class="text-end"><?php echo e(number_format($run['qty_target'], 2)); ?></td>
                                                <td class="text-end text-success fw-semibold"><?php echo e(number_format($run['qty_ok'], 2)); ?></td>
                                                <td class="text-end <?php echo e($run['qty_reject'] > 0 ? 'text-danger fw-semibold' : 'text-muted'); ?>">
                                                    <?php echo e(number_format($run['qty_reject'])); ?>

                                                </td>
                                                <td>
                                                    <span class="badge rounded-pill text-bg-<?php echo e($run['status'] === 'completed' ? 'success' : ($run['status'] === 'running' ? 'warning text-dark' : 'secondary')); ?>">
                                                        <?php echo e($run['status']); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <?php echo e($run['started_at'] ? \Carbon\Carbon::parse($run['started_at'])->format('d/m/Y H:i') : '—'); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($run['completed_at'] ? \Carbon\Carbon::parse($run['completed_at'])->format('d/m/Y H:i') : '—'); ?>

                                                </td>
                                            </tr>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </div>
                </div>

                <div class="modal-footer border-0 pt-0">
                    <button type="button" wire:click="closeDetailModal" class="btn btn-light border rounded-3 px-4">
                        Tutup
                    </button>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showBomModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showBomModal): ?> background: rgba(15,23,42,.7); z-index:1060; <?php else: ?> display:none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">BOM Items</h5>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($detail && $detail['spk']): ?>
                            <div class="text-muted small">SPK: <?php echo e($detail['spk']['spk_number']); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <button type="button" class="btn-close" wire:click="closeBomModal"></button>
                </div>

                <div class="modal-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($bomItems)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0 small">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-3">Material</th>
                                        <th class="text-end">Kebutuhan</th>
                                        <th>Satuan</th>
                                        <th class="text-end">Stok Tersedia</th>
                                        <th class="text-end">Requested</th>
                                        <th class="text-end">Issued</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $bomItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <tr>
                                        <td class="ps-3 fw-semibold"><?php echo e($bom['material']); ?></td>
                                        <td class="text-end"><?php echo e(number_format($bom['kebutuhan'], 2)); ?></td>
                                        <td><?php echo e($bom['satuan']); ?></td>
                                        <td class="text-end <?php echo e($bom['stok_tersedia'] >= $bom['kebutuhan'] ? 'text-success' : 'text-danger'); ?> fw-semibold">
                                            <?php echo e(number_format($bom['stok_tersedia'], 2)); ?>

                                        </td>
                                        <td class="text-end text-muted"><?php echo e(number_format($bom['requested_qty'], 2)); ?></td>
                                        <td class="text-end text-muted"><?php echo e(number_format($bom['issued_qty'], 2)); ?></td>
                                        <td>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bom['stok_tersedia'] < $bom['kebutuhan']): ?>
                                                <span class="badge text-bg-danger rounded-pill">Stok Kurang</span>
                                            <?php else: ?>
                                                <span class="badge text-bg-success rounded-pill">OK</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                            Tidak ada BOM items untuk SPK ini.
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="modal-footer border-0 pt-0">
                    <button type="button" wire:click="closeBomModal" class="btn btn-light border rounded-3 px-4">
                        Tutup
                    </button>
                </div>
            </div>
        </div>
    </div>

        <?php
        $__scriptKey = '3304522443-0';
        ob_start();
    ?>
    <script>
        window.scanLogFocus = function () {
            const el = document.getElementById('scanLogInput');
            if (el) el.focus();
        };

        Livewire.on('scan-log-focus-input', () => {
            setTimeout(() => scanLogFocus(), 200);
        });

        document.addEventListener('livewire:navigated', () => {
            setTimeout(() => scanLogFocus(), 300);
        });
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/livewire/pages/scan-log/index.blade.php ENDPATH**/ ?>