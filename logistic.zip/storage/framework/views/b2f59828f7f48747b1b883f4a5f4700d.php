<div>
    <style>
        .qc-camera-box { min-height: 320px; }
        #qcCameraScanner { width: 100%; min-height: 320px; }
        #qcCameraScanner video { border-radius: 1rem; object-fit: cover; }

        @media (max-width: 767.98px) {
            .qc-camera-box { min-height: 260px; }
            #qcCameraScanner { min-height: 260px; }

            .qc-scan-input {
                font-size: 1.35rem !important;
                height: 58px;
            }

            .qc-action-stack {
                display: grid !important;
                grid-template-columns: 1fr;
                gap: .35rem;
            }

            .qc-action-stack .btn,
            .qc-action-stack a {
                width: 100%;
            }
        }
    </style>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h4 class="fw-bold mb-1">Temporary Warehouse QC</h4>
            <div class="text-muted">Buat troli per item, scan barcode dus ke troli, lalu kirim ke FGW.</div>
        </div>

        <div>
            <button type="button" class="btn btn-primary rounded-3 px-4" wire:click="openCreateTrolleyModal">
                <i class="bi bi-cart-plus me-1"></i>
                Buat Troli
            </button>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-3"><?php echo e(session('success')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger border-0 shadow-sm rounded-3"><?php echo e(session('error')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Sudah Scan TW</div>
                    <div class="fs-3 fw-bold text-success"><?php echo e($summary->total_tw_scanned); ?></div>
                    <div class="small text-muted">Siap masuk troli</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Troli Open</div>
                    <div class="fs-3 fw-bold"><?php echo e($summary->total_open_trolley); ?></div>
                    <div class="small text-muted">Sedang diisi</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Troli Complete</div>
                    <div class="fs-3 fw-bold"><?php echo e($summary->total_complete_trolley); ?></div>
                    <div class="small text-muted">Siap kirim FGW</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Kirim FGW</div>
                    <div class="fs-3 fw-bold"><?php echo e($summary->total_sent_fgw); ?></div>
                    <div class="small text-muted">Troli terkirim</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Troli Aktif</h5>
            <div class="text-muted small">Setiap troli hanya boleh diisi oleh satu jenis item.</div>
        </div>

        <div class="card-body px-4 pb-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">Troli</th>
                            <th>Item</th>
                            <th>Barcode</th>
                            <th>Progress</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $trolleys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trolley): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $percent = !is_null($trolley->capacity) && $trolley->capacity > 0
                                    ? ($trolley->total_items / $trolley->capacity) * 100
                                    : 0;
                            ?>

                            <tr>
                                <td class="ps-4">
                                    <div class="fw-semibold"><?php echo e($trolley->trolley_code); ?></div>
                                    <small class="text-muted">
                                        Kapasitas: <?php echo e($trolley->capacity ? $trolley->capacity . ' dus' : '∞'); ?>

                                    </small>
                                </td>

                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trolley->item_name): ?>
                                        <div class="fw-semibold"><?php echo e($trolley->item_name); ?></div>
                                        <small class="text-muted"><?php echo e($trolley->item_code); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>

                                <td><code><?php echo e($trolley->barcode); ?></code></td>

                                <td style="min-width: 200px;">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span><?php echo e($trolley->total_items); ?>/<?php echo e($trolley->capacity ?? '∞'); ?> dus</span>
                                        <span><?php echo e(number_format($percent, 0)); ?>%</span>
                                    </div>

                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar" style="width: <?php echo e($percent); ?>%"></div>
                                    </div>
                                </td>

                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trolley->status === 'COMPLETE'): ?>
                                        <span class="badge rounded-pill text-bg-success">COMPLETE</span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill text-bg-primary">OPEN</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>

                                <td class="text-end pe-4">
                                    <div class="d-flex justify-content-end gap-1 qc-action-stack">
                                        <button
                                            type="button"
                                            class="btn btn-sm btn-light border rounded-3"
                                            wire:click="openTrolleyDetailModal(<?php echo e($trolley->id); ?>)"
                                        >
                                            <i class="bi bi-list-check me-1"></i>
                                            Detail
                                        </button>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trolley->status === 'OPEN'): ?>
                                            <button
                                                type="button"
                                                class="btn btn-sm btn-primary rounded-3"
                                                wire:click="openScanModal(
                                                    <?php echo e($trolley->id); ?>,
                                                    '<?php echo e($trolley->trolley_code); ?>',
                                                    '<?php echo e($trolley->barcode); ?>',
                                                    <?php echo e($trolley->capacity ?? 'null'); ?>,
                                                    <?php echo e($trolley->total_items); ?>,
                                                    '<?php echo e(addslashes($trolley->item_name ?? '')); ?>'
                                                )"
                                            >
                                                <i class="bi bi-camera me-1"></i>
                                                Scan Dus
                                            </button>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trolley->total_items > 0): ?>
                                                <button
                                                    type="button"
                                                    class="btn btn-sm btn-warning rounded-3"
                                                    onclick="qcConfirmForceComplete(<?php echo e($trolley->id); ?>)"
                                                >
                                                    <i class="bi bi-check2-circle me-1"></i>
                                                    Kunci
                                                </button>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trolley->status === 'COMPLETE'): ?>
                                            <a
                                                href="<?php echo e(route('temporary-warehouse.print-trolley-qr', ['trolley_id' => $trolley->id])); ?>"
                                                target="_blank"
                                                class="btn btn-sm btn-light border rounded-3"
                                            >
                                                <i class="bi bi-qr-code me-1"></i>
                                                QR
                                            </a>

                                            <button
                                                type="button"
                                                class="btn btn-sm btn-success rounded-3"
                                                onclick="qcConfirmSendToFgw(<?php echo e($trolley->id); ?>)"
                                            >
                                                <i class="bi bi-truck me-1"></i>
                                                Kirim FGW
                                            </button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-5">
                                    <i class="bi bi-cart-x fs-1 d-block mb-2"></i>
                                    Belum ada troli aktif.
                                </td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showCreateTrolleyModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showCreateTrolleyModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Buat Troli Baru</h5>
                        <div class="text-muted small">Pilih item — troli hanya boleh diisi satu jenis item.</div>
                    </div>
                    <button type="button" class="btn-close" wire:click="closeCreateTrolleyModal"></button>
                </div>

                <form wire:submit.prevent="submitCreateTrolley">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Item <span class="text-danger">*</span></label>
                            <select wire:model="createTrolleyItemId" class="form-select rounded-3 <?php $__errorArgs = ['createTrolleyItemId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Pilih Item</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->item_code); ?> — <?php echo e($item->item_name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['createTrolleyItemId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">
                                Kapasitas
                                <span class="text-muted fw-normal small">(kosongkan = tidak terbatas)</span>
                            </label>
                            <input
                                type="number"
                                wire:model="createTrolleyCapacity"
                                class="form-control rounded-3"
                                min="1"
                                placeholder="contoh: 20"
                            >
                        </div>
                    </div>

                    <div class="modal-footer border-0 pt-0">
                        <button type="button" wire:click="closeCreateTrolleyModal" class="btn btn-light border rounded-3 px-4">
                            Batal
                        </button>
                        <button type="submit" class="btn btn-primary rounded-3 px-4">
                            <i class="bi bi-cart-plus me-1"></i>
                            Buat Troli
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showTrolleyDetailModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showTrolleyDetailModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Detail Isi Troli</h5>
                    </div>
                    <button type="button" class="btn-close" wire:click="closeTrolleyDetailModal"></button>
                </div>

                <div class="modal-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('detail_success')): ?>
                        <div class="alert alert-success border-0 rounded-3"><?php echo e(session('detail_success')); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('detail_error')): ?>
                        <div class="alert alert-danger border-0 rounded-3"><?php echo e(session('detail_error')); ?></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($detailTrolley): ?>
                        <?php
                            $detailPercent = !is_null($detailTrolley->capacity) && $detailTrolley->capacity > 0
                                ? ($detailTrolley->total_items / $detailTrolley->capacity) * 100
                                : 0;
                        ?>

                        <div class="border rounded-4 p-3 mb-3 bg-light">
                            <div class="row g-3 align-items-center">
                                <div class="col-md-4">
                                    <div class="small text-muted">Troli</div>
                                    <div class="fw-bold fs-5"><?php echo e($detailTrolley->trolley_code); ?></div>
                                    <code><?php echo e($detailTrolley->barcode); ?></code>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Status</div>
                                    <span class="badge rounded-pill <?php echo e($detailTrolley->status === 'COMPLETE' ? 'text-bg-success' : 'text-bg-primary'); ?>">
                                        <?php echo e($detailTrolley->status); ?>

                                    </span>
                                </div>

                                <div class="col-md-4">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span>Isi Troli</span>
                                        <span><?php echo e($detailTrolley->total_items); ?>/<?php echo e($detailTrolley->capacity ?? '∞'); ?></span>
                                    </div>
                                    <div class="progress" style="height: 10px;">
                                        <div class="progress-bar" style="width: <?php echo e($detailPercent); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Barcode</th>
                                    <th>Box</th>
                                    <th>Item</th>
                                    <th>SPK</th>
                                    <th>Qty</th>
                                    <th>
                                        QC Scan By
                                        <small class="text-muted fw-normal d-block" style="font-size:.7rem;">prod_qc_scanned_by</small>
                                    </th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $detailTrolleyItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <tr>
                                        <td><code><?php echo e($item->barcode); ?></code></td>
                                        <td><?php echo e($item->box_number); ?></td>
                                        <td>
                                            <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                            <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                        </td>
                                        <td><?php echo e($item->spk_number); ?></td>
                                        <td><?php echo e(number_format($item->qty, 0, ',', '.')); ?> <?php echo e($item->uom); ?></td>
                                        <td>
                                            <div class="fw-semibold small"><?php echo e($item->scanned_by_name ?? '-'); ?></div>
                                            <small class="text-muted">
                                                <?php echo e($item->scanned_at ? \Carbon\Carbon::parse($item->scanned_at)->format('d M Y H:i') : '-'); ?>

                                            </small>
                                        </td>
                                        <td class="text-end">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($detailTrolley && $detailTrolley->status === 'OPEN'): ?>
                                                <button
                                                    type="button"
                                                    class="btn btn-sm btn-light border text-danger rounded-3"
                                                    onclick="qcConfirmRemoveDus(<?php echo e($detailTrolley->id); ?>, <?php echo e($item->packing_unit_id); ?>)"
                                                >
                                                    <i class="bi bi-x-circle me-1"></i>
                                                    Remove
                                                </button>
                                            <?php else: ?>
                                                <span class="text-muted small">Locked</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-5">
                                            Belum ada dus di troli ini.
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="modal-footer border-0 pt-0">
                    <button type="button" wire:click="closeTrolleyDetailModal" class="btn btn-light border rounded-3 px-4">
                        Tutup
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showScanModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showScanModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-lg modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Scan Dus ke Troli</h5>
                        <div class="text-muted small">
                            Khusus item: <strong><?php echo e($selectedTrolleyItemName ?: '-'); ?></strong>
                            &nbsp;|&nbsp;Hanya dus status <span class="badge text-bg-success">TW SCANNED</span> yang boleh masuk.
                        </div>
                    </div>
                    <button type="button" class="btn-close" wire:click="closeScanModal"></button>
                </div>

                <form wire:submit.prevent="scanDus">
                    <div class="modal-body">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_success')): ?>
                            <div class="alert alert-success border-0 rounded-3"><?php echo e(session('scan_success')); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_error')): ?>
                            <div class="alert alert-danger border-0 rounded-3"><?php echo e(session('scan_error')); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="border rounded-4 p-3 mb-3 bg-light">
                            <div class="small text-muted">Troli Dipilih</div>
                            <div class="fw-bold fs-5"><?php echo e($selectedTrolleyCode); ?></div>
                            <code><?php echo e($selectedTrolleyBarcode); ?></code>

                            <?php
                                $selectedPercent = !is_null($selectedTrolleyCapacity) && $selectedTrolleyCapacity > 0
                                    ? ($selectedTrolleyTotalItems / $selectedTrolleyCapacity) * 100
                                    : 0;
                            ?>

                            <div class="mt-3">
                                <div class="d-flex justify-content-between small mb-1">
                                    <span>Isi Troli</span>
                                    <span><?php echo e($selectedTrolleyTotalItems); ?>/<?php echo e($selectedTrolleyCapacity ?? '∞'); ?></span>
                                </div>
                                <div class="progress" style="height: 10px;">
                                    <div class="progress-bar" style="width: <?php echo e($selectedPercent); ?>%"></div>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-lg-7">
                                <div wire:ignore class="border rounded-4 overflow-hidden bg-dark qc-camera-box">
                                    <div id="qcCameraScanner"></div>
                                </div>

                                <div id="qcCameraScannerStatus" class="small text-muted mt-2">
                                    Menunggu kamera...
                                </div>

                                <div class="d-flex gap-2 mt-2">
                                    <button type="button" class="btn btn-sm btn-light border rounded-3" onclick="qcStartCamera()">
                                        <i class="bi bi-camera-video me-1"></i>
                                        Nyalakan Kamera
                                    </button>

                                    <button type="button" class="btn btn-sm btn-light border rounded-3" onclick="qcStopCamera()">
                                        <i class="bi bi-camera-video-off me-1"></i>
                                        Matikan Kamera
                                    </button>
                                </div>
                            </div>

                            <div class="col-lg-5">
                                <label class="form-label fw-semibold">Barcode Dus</label>

                                <input
                                    type="text"
                                    id="qcPackingBarcodeInput"
                                    wire:model.defer="packingBarcode"
                                    class="form-control form-control-lg rounded-3 text-center fw-bold qc-scan-input"
                                    placeholder="Scan barcode dus"
                                    autocomplete="off"
                                >

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['packingBarcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <div class="form-text mb-3">Bisa kamera HP atau scanner gun.</div>

                                <button type="submit" class="btn btn-primary rounded-3 px-4 w-100">
                                    <i class="bi bi-upc-scan me-1"></i>
                                    Masukkan ke Troli
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

        <?php
        $__scriptKey = '258680767-0';
        ob_start();
    ?>
    <script>
        let qcScannerInstance = null;
        let qcScannerReady = false;
        let qcScannerBusy = false;
        let qcScannerLastCode = '';
        let qcScannerLastTime = 0;

        function qcSetStatus(msg, isError = false) {
            const el = document.getElementById('qcCameraScannerStatus');
            if (!el) return;
            el.innerText = msg;
            el.classList.toggle('text-danger', isError);
            el.classList.toggle('text-muted', !isError);
        }

        function loadQcScript() {
            return new Promise((resolve, reject) => {
                if (window.Html5Qrcode) { resolve(); return; }
                const existing = document.getElementById('html5-qrcode-script');
                if (existing) {
                    existing.addEventListener('load', resolve);
                    existing.addEventListener('error', reject);
                    return;
                }
                const s = document.createElement('script');
                s.id = 'html5-qrcode-script';
                s.src = 'https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js';
                s.onload = resolve;
                s.onerror = reject;
                document.body.appendChild(s);
            });
        }

        window.qcFocusInput = function () {
            setTimeout(() => {
                const input = document.getElementById('qcPackingBarcodeInput');
                if (input) { input.focus(); input.select(); }
            }, 150);
        }

        window.qcResumeCamera = function () {
            qcScannerBusy = false;
            try {
                if (qcScannerInstance && qcScannerReady) qcScannerInstance.resume();
            } catch (e) {}
            qcSetStatus('Kamera standby. Arahkan ke barcode dus.');
            qcFocusInput();
        }

        window.qcStartCamera = async function () {
            const el = document.getElementById('qcCameraScanner');
            if (!el) return;

            try {
                await loadQcScript();

                if (qcScannerReady && qcScannerInstance) { qcResumeCamera(); return; }

                el.innerHTML = '';
                qcScannerInstance = new Html5Qrcode('qcCameraScanner');

                const config = {
                    fps: 12,
                    qrbox: function(w, h) {
                        const isMobile = window.innerWidth < 768;
                        return {
                            width: Math.floor(w * (isMobile ? 0.92 : 0.86)),
                            height: Math.floor(h * (isMobile ? 0.28 : 0.32))
                        };
                    },
                    aspectRatio: window.innerWidth < 768 ? 1.333 : 1.777,
                    disableFlip: false,
                    formatsToSupport: [
                        Html5QrcodeSupportedFormats.CODE_128,
                        Html5QrcodeSupportedFormats.CODE_39,
                        Html5QrcodeSupportedFormats.EAN_13,
                        Html5QrcodeSupportedFormats.EAN_8,
                        Html5QrcodeSupportedFormats.UPC_A,
                        Html5QrcodeSupportedFormats.UPC_E
                    ]
                };

                await qcScannerInstance.start(
                    { facingMode: 'environment' },
                    config,
                    async function(decodedText) {
                        const code = String(decodedText).trim();
                        const now = Date.now();
                        if (!code || qcScannerBusy) return;
                        if (qcScannerLastCode === code && (now - qcScannerLastTime) < 2500) return;

                        qcScannerBusy = true;
                        qcScannerLastCode = code;
                        qcScannerLastTime = now;
                        qcSetStatus('Terbaca: ' + code + '. Menyimpan...');

                        try {
                            if (qcScannerInstance && qcScannerReady) qcScannerInstance.pause(true);
                        } catch (e) {}

                        const input = document.getElementById('qcPackingBarcodeInput');
                        if (input) {
                            input.value = code;
                            input.dispatchEvent(new Event('input', { bubbles: true }));
                        }

                        try {
                            await $wire.set('packingBarcode', code);
                            await $wire.scanDus();
                        } catch (e) {
                            qcSetStatus('Gagal mengirim ke server.', true);
                            setTimeout(() => qcResumeCamera(), 800);
                        }
                    },
                    function() {}
                );

                qcScannerReady = true;
                qcScannerBusy = false;
                qcSetStatus('Kamera standby. Arahkan ke barcode dus.');
                qcFocusInput();
            } catch (e) {
                qcScannerReady = false;
                qcScannerBusy = false;
                qcSetStatus('Kamera gagal. Pakai HTTPS/localhost dan izinkan kamera.', true);
                qcFocusInput();
            }
        }

        window.qcStopCamera = async function () {
            try {
                if (qcScannerInstance && qcScannerReady) {
                    await qcScannerInstance.stop();
                    await qcScannerInstance.clear();
                }
            } catch (e) {}

            qcScannerInstance = null;
            qcScannerReady = false;
            qcScannerBusy = false;
            qcScannerLastCode = '';
            qcScannerLastTime = 0;

            const el = document.getElementById('qcCameraScanner');
            if (el) el.innerHTML = '';

            qcSetStatus('Kamera dimatikan.');
        }

        Livewire.on('scan-modal-opened', () => {
            setTimeout(() => { qcFocusInput(); qcStartCamera(); }, 450);
        });

        Livewire.on('scan-ready-again', () => {
            setTimeout(() => qcResumeCamera(), 450);
        });

        Livewire.on('scan-modal-closed', () => {
            qcStopCamera();
        });

        window.qcConfirmSendToFgw = function (id) {
            Swal.fire({
                title: 'Kirim troli ke FGW?',
                text: 'Troli complete akan dikirim ke Finish Goods Warehouse.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, kirim',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn btn-success rounded-3 px-4 ms-2',
                    cancelButton: 'btn btn-light border rounded-3 px-4'
                },
                buttonsStyling: false
            }).then((result) => {
                if (result.isConfirmed) $wire.sendToFgw(id);
            });
        }

        window.qcConfirmForceComplete = function (id) {
            Swal.fire({
                title: 'Kunci troli?',
                text: 'Troli akan dikunci & tidak bisa diubah lagi.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Kunci',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn btn-warning rounded-3 px-4 ms-2',
                    cancelButton: 'btn btn-light border rounded-3 px-4'
                },
                buttonsStyling: false
            }).then((result) => {
                if (result.isConfirmed) $wire.forceCompleteTrolley(id);
            });
        }

        window.qcConfirmRemoveDus = function (trolleyId, packingUnitId) {
            Swal.fire({
                title: 'Keluarkan dus?',
                text: 'Status dus akan kembali menjadi PRINTED.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, keluarkan',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn btn-danger rounded-3 px-4 ms-2',
                    cancelButton: 'btn btn-light border rounded-3 px-4'
                },
                buttonsStyling: false
            }).then((result) => {
                if (result.isConfirmed) $wire.removeDusFromTrolley(trolleyId, packingUnitId);
            });
        }
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/livewire/pages/temporary-warehouse-qc/index.blade.php ENDPATH**/ ?>