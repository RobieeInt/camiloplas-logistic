<div>
    <h4 class="fw-bold mb-3">Dashboard</h4>
    <p class="text-muted"> Logistic Module</p>
</div>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/livewire/pages/dashboard/index.blade.php ENDPATH**/ ?>