<div>
    <style>
        @media (max-width: 767.98px) {
            .loading-summary .fs-2 {
                font-size: 1.5rem !important;
            }

            .loading-table th,
            .loading-table td {
                font-size: .85rem;
                white-space: nowrap;
            }

            .loading-action-stack {
                display: grid !important;
                grid-template-columns: 1fr;
                gap: .5rem;
            }

            .loading-action-stack .btn {
                width: 100%;
            }
        }
    </style>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Ready To Deliver</h4>
            <div class="text-muted">
                Pilih SO / DO, tentukan truck, scan dus FGW ke truck, lalu complete loading.
            </div>
        </div>

        <button
            type="button"
            class="btn btn-primary rounded-3 px-4"
            wire:click="openCreateDoModal"
        >
            <i class="bi bi-plus-circle me-1"></i>
            Buat DO
        </button>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success rounded-3 border-0 shadow-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger rounded-3 border-0 shadow-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('create_do_error')): ?>
        <div class="alert alert-danger rounded-3 border-0 shadow-sm">
            <?php echo e(session('create_do_error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="row g-3 mb-4 loading-summary">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Ready Order</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->ready_orders); ?></div>
                    <div class="small text-muted">Belum loading</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Sedang Loading</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->loading_orders); ?></div>
                    <div class="small text-muted">Proses truck</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Loaded</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->loaded_orders); ?></div>
                    <div class="small text-muted">Siap dokumen</div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Stock FGW</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->stock_fgw); ?></div>
                    <div class="small text-muted">Dus available</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Pilih SO / DO</h5>
            <div class="text-muted small">
                Loading hanya bisa dilakukan untuk order READY atau LOADING.
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 loading-table">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">DO</th>
                        <th>SO</th>
                        <th>Customer</th>
                        <th>Truck</th>
                        <th>Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $readyOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-semibold"><?php echo e($order->do_number); ?></div>
                                <small class="text-muted">
                                    <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M Y')); ?>

                                </small>
                            </td>

                            <td><?php echo e($order->so_number); ?></td>

                            <td><?php echo e($order->customer_name); ?></td>

                            <td>
                                <span class="badge rounded-pill text-bg-light border">
                                    <?php echo e($order->truck_number ?: '-'); ?>

                                </span>
                            </td>

                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->status === 'READY'): ?>
                                    <span class="badge rounded-pill text-bg-primary">READY</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill text-bg-warning">LOADING</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            <td class="text-end pe-4">
                                <button
                                    type="button"
                                    class="btn btn-sm btn-primary rounded-3"
                                    wire:click="openLoadingModal(<?php echo e($order->id); ?>)"
                                >
                                    <i class="bi bi-truck me-1"></i>
                                    Loading
                                </button>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                Belum ada SO / DO ready loading.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Riwayat Loaded</h5>
            <div class="text-muted small">
                Order yang sudah selesai loading dan siap cetak dokumen.
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 loading-table">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">DO</th>
                        <th>SO</th>
                        <th>Customer</th>
                        <th>Truck</th>
                        <th>Progress</th>
                        <th>Loaded</th>
                        <th>User</th>
                        <th class="text-end pe-4">Dokumen</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentLoadedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-semibold"><?php echo e($order->do_number); ?></div>
                                <span class="badge rounded-pill text-bg-success"><?php echo e($order->status); ?></span>
                            </td>

                            <td><?php echo e($order->so_number); ?></td>
                            <td><?php echo e($order->customer_name); ?></td>
                            <td><?php echo e($order->truck_number ?: '-'); ?></td>

                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->total_required > 0): ?>
                                    <?php echo e($order->total_loaded); ?>/<?php echo e($order->total_required); ?> dus
                                <?php else: ?>
                                    <?php echo e($order->total_loaded); ?> dus
                                    <small class="text-muted d-block">tanpa target</small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            <td>
                                <?php echo e($order->loaded_at ? \Carbon\Carbon::parse($order->loaded_at)->format('d M Y H:i') : '-'); ?>

                            </td>

                            <td><?php echo e($order->loaded_by_name ?? '-'); ?></td>
                            <td class="text-end pe-4">
                                <div class="d-flex justify-content-end gap-1">
                                    <a
                                        href="<?php echo e(route('loading.print-do', $order->id)); ?>"
                                        target="_blank"
                                        class="btn btn-sm btn-light border rounded-3"
                                    >
                                        <i class="bi bi-printer me-1"></i>
                                        DO
                                    </a>

                                    <a
                                        href="<?php echo e(route('loading.print-surat-jalan', $order->id)); ?>"
                                        target="_blank"
                                        class="btn btn-sm btn-light border rounded-3"
                                    >
                                        <i class="bi bi-file-earmark-text me-1"></i>
                                        Surat Jalan
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                Belum ada order loaded.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showCreateDoModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showCreateDoModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-lg modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">
                            <i class="bi bi-plus-circle me-2 text-primary"></i>
                            Buat Delivery Order
                        </h5>
                        <div class="text-muted small">Gabungkan 1 atau lebih SO menjadi satu DO.</div>
                    </div>
                    <button type="button" class="btn-close" wire:click="closeCreateDoModal"></button>
                </div>

                <form wire:submit.prevent="submitCreateDo">
                    <div class="modal-body">

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('create_do_error')): ?>
                            <div class="alert alert-danger rounded-3 border-0">
                                <?php echo e(session('create_do_error')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        
                        <div class="border rounded-4 p-3 mb-3">
                            <div class="fw-semibold small mb-2 text-primary">
                                <i class="bi bi-1-circle-fill me-1"></i>
                                Pilih SO
                            </div>

                            <div class="d-flex gap-2 mb-2">
                                <select
                                    wire:model.live="createDoAddSoId"
                                    class="form-select rounded-3 flex-grow-1"
                                >
                                    <option value="">— Pilih SO untuk ditambahkan —</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $salesOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!in_array($so->id, $createDoSoIds)): ?>
                                            <option value="<?php echo e($so->id); ?>">
                                                <?php echo e($so->so_number); ?> — <?php echo e($so->customer_name); ?>

                                            </option>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                                <button
                                    type="button"
                                    class="btn btn-primary rounded-3 px-3"
                                    wire:click="addSoToDo"
                                    <?php if(!$createDoAddSoId): echo 'disabled'; endif; ?>
                                >
                                    <i class="bi bi-plus-lg me-1"></i>
                                    Tambah
                                </button>
                            </div>

                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($createDoSoIds) > 0): ?>
                                <div class="d-flex flex-wrap gap-2 pt-1">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $createDoSos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <span class="badge rounded-pill text-bg-primary d-inline-flex align-items-center gap-2 px-3 py-2" style="font-size: .82rem; font-weight: 500;">
                                            <i class="bi bi-file-earmark-text"></i>
                                            <?php echo e($so->so_number); ?>

                                            <span class="fw-normal opacity-75"><?php echo e($so->customer_name); ?></span>
                                            <button
                                                type="button"
                                                class="btn-close btn-close-white ms-1"
                                                style="font-size: .55rem;"
                                                wire:click="removeSoFromDo(<?php echo e($so->id); ?>)"
                                            ></button>
                                        </span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="text-muted small text-center py-2 bg-light rounded-3">
                                    <i class="bi bi-info-circle me-1"></i>
                                    Belum ada SO dipilih
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold">
                                <span class="text-primary me-1"><i class="bi bi-2-circle-fill"></i></span>
                                DO Number
                            </label>
                            <input
                                type="text"
                                wire:model="createDoNumber"
                                class="form-control form-control-lg rounded-3 <?php $__errorArgs = ['createDoNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="DO-YYYYMMDD-0001"
                            >
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['createDoNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <div class="form-text">Auto-generated, bisa diubah manual.</div>
                        </div>

                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($createDoSoIds) > 0 && count($createDoDetails) > 0): ?>
                            <div class="border rounded-4 overflow-hidden">
                                <div class="bg-light px-4 py-2 border-bottom d-flex justify-content-between align-items-center">
                                    <span class="fw-semibold small">
                                        <span class="text-primary me-1"><i class="bi bi-3-circle-fill"></i></span>
                                        Item dari SO terpilih
                                    </span>
                                    <span class="badge rounded-pill text-bg-light border text-muted">0 = tanpa target</span>
                                </div>

                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th class="ps-4">Item</th>
                                            <th class="text-end">Sisa Order SO</th>
                                            <th class="text-end">Stok FGW</th>
                                            <th style="width: 160px;">
                                                Target Box
                                                <span class="fw-normal text-muted">(opsional)</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $createDoDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <?php
                                                $stockDus      = (int) $detail->stock_dus;
                                                $stockPcs      = (int) $detail->stock_pcs;
                                                $qtyPerBox     = $detail->qty_per_box ? (int) $detail->qty_per_box : null;
                                                $remainingPcs  = (int) $detail->remaining_pcs;
                                                $alreadyLoaded = (int) $detail->already_loaded_pcs;
                                                $totalQty      = (int) $detail->qty;
                                                $stockEnough   = $stockPcs >= $remainingPcs;
                                            ?>
                                            <tr>
                                                <td class="ps-4">
                                                    <div class="fw-semibold"><?php echo e($detail->item_name); ?></div>
                                                    <small class="text-muted"><?php echo e($detail->item_code); ?></small>
                                                </td>
                                                <td class="text-end">
                                                    <div class="fw-semibold <?php echo e($remainingPcs <= 0 ? 'text-success' : ''); ?>">
                                                        <?php echo e(number_format($remainingPcs)); ?>

                                                        <small class="fw-normal text-muted"><?php echo e($detail->uom); ?></small>
                                                    </div>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($alreadyLoaded > 0): ?>
                                                        <small class="text-muted">
                                                            Total <?php echo e(number_format($totalQty)); ?> · Terkirim <?php echo e(number_format($alreadyLoaded)); ?>

                                                        </small>
                                                    <?php else: ?>
                                                        <small class="text-muted">Total order</small>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </td>
                                                <td class="text-end">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($stockDus > 0): ?>
                                                        <div class="fw-semibold <?php echo e($stockEnough ? 'text-success' : 'text-warning'); ?>">
                                                            <?php echo e($stockDus); ?> dus
                                                        </div>
                                                        <small class="text-muted">
                                                            <?php echo e(number_format($stockPcs)); ?> PCS
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($qtyPerBox): ?>
                                                                · <?php echo e(number_format($qtyPerBox)); ?>/dus
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </small>
                                                    <?php else: ?>
                                                        <div class="text-danger fw-semibold">0 dus</div>
                                                        <small class="text-muted">Belum ada stok</small>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </td>
                                                <td class="pe-4">
                                                    <input
                                                        type="number"
                                                        wire:model="createDoBoxes.<?php echo e($detail->item_id); ?>"
                                                        class="form-control rounded-3 text-center fw-semibold"
                                                        min="0"
                                                        placeholder="0"
                                                        <?php if($stockDus > 0): ?> max="<?php echo e($stockDus); ?>" <?php endif; ?>
                                                    >
                                                    <div class="form-text text-center">
                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($stockDus > 0): ?>
                                                            maks <?php echo e($stockDus); ?> dus
                                                        <?php else: ?>
                                                            0 = tanpa target
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif(count($createDoSoIds) > 0 && count($createDoDetails) === 0): ?>
                            <div class="text-center text-muted py-4 border rounded-4">
                                <i class="bi bi-inbox fs-2 d-block mb-2 opacity-50"></i>
                                SO yang dipilih belum memiliki detail item.
                            </div>
                        <?php else: ?>
                            <div class="text-center text-muted py-4 border rounded-4 bg-light">
                                <i class="bi bi-arrow-up-circle fs-2 d-block mb-2 opacity-25"></i>
                                Tambahkan SO untuk melihat item yang akan di-DO-kan.
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </div>

                    <div class="modal-footer border-0 pt-0">
                        <button type="button" wire:click="closeCreateDoModal" class="btn btn-light border rounded-3 px-4">
                            Batal
                        </button>
                        <button
                            type="submit"
                            class="btn btn-primary rounded-3 px-4"
                            <?php if(count($createDoSoIds) === 0 || count($createDoDetails) === 0): echo 'disabled'; endif; ?>
                        >
                            <i class="bi bi-check-circle me-1"></i>
                            Generate DO
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showLoadingModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showLoadingModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Loading ke Truck</h5>
                        <div class="text-muted small">
                            Scan barcode dus saat barang masuk ke truck / container.
                        </div>
                    </div>

                    <button type="button" class="btn-close" wire:click="closeLoadingModal"></button>
                </div>

                <form wire:submit.prevent="scanDus">
                    <div class="modal-body">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_success')): ?>
                            <div class="alert alert-success rounded-3 border-0">
                                <?php echo e(session('scan_success')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_error')): ?>
                            <div class="alert alert-danger rounded-3 border-0">
                                <?php echo e(session('scan_error')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedOrder): ?>
                            
                            <div class="border rounded-4 p-3 mb-3 bg-light">
                                <div class="row g-3 align-items-center">
                                    <div class="col-lg-4">
                                        <div class="small text-muted">Delivery Order</div>
                                        <div class="fw-bold fs-5"><?php echo e($selectedOrder->do_number); ?></div>
                                        <div class="small text-muted"><?php echo e($selectedOrder->so_number); ?></div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="small text-muted">Customer</div>
                                        <div class="fw-semibold"><?php echo e($selectedOrder->customer_name); ?></div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="small text-muted">Status</div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedOrder->status === 'READY'): ?>
                                            <span class="badge rounded-pill text-bg-primary">READY</span>
                                        <?php elseif($selectedOrder->status === 'LOADING'): ?>
                                            <span class="badge rounded-pill text-bg-warning">LOADING</span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill text-bg-success"><?php echo e($selectedOrder->status); ?></span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="border rounded-4 p-3 mb-3 <?php $__errorArgs = ['truckNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="fw-semibold small">
                                        <i class="bi bi-truck me-1 text-primary"></i>
                                        Truck / Kendaraan
                                    </span>
                                    <span class="badge text-bg-danger rounded-pill" style="font-size: .7rem;">
                                        <i class="bi bi-exclamation-circle me-1"></i>Wajib diisi
                                    </span>
                                </div>

                                <div class="row g-3 align-items-end">
                                    <div class="col-lg-5">
                                        <label class="form-label small text-muted mb-1">Pilih dari master kendaraan</label>
                                        <select
                                            class="form-select rounded-3"
                                            wire:change="selectVehicle($event.target.value)"
                                        >
                                            <option value="">— Pilih kendaraan —</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <option
                                                    value="<?php echo e($v->id); ?>"
                                                    <?php echo e($selectedVehicleId == $v->id ? 'selected' : ''); ?>

                                                >
                                                    <?php echo e($v->vehicle_number); ?>

                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($v->vehicle_type): ?> (<?php echo e($v->vehicle_type); ?>) <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($v->driver_name): ?> — <?php echo e($v->driver_name); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </select>
                                    </div>

                                    <div class="col-md-1 d-none d-lg-flex align-items-center justify-content-center pb-1">
                                        <div class="vr" style="height: 36px;"></div>
                                    </div>

                                    <div class="col-lg-6">
                                        <label class="form-label small text-muted mb-1">
                                            No. Polisi
                                            <span class="fw-normal">(atau ketik manual)</span>
                                        </label>
                                        <input
                                            type="text"
                                            wire:model="truckNumber"
                                            class="form-control rounded-3 text-uppercase fw-semibold <?php $__errorArgs = ['truckNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="cth: B 9123 XYZ"
                                            autocomplete="off"
                                        >
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['truckNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <label class="form-label small text-muted mb-1">
                                        Nama Driver
                                        <span class="badge text-bg-danger rounded-pill ms-1" style="font-size:.7rem;">Wajib</span>
                                    </label>
                                    <input
                                        type="text"
                                        wire:model="driverName"
                                        class="form-control rounded-3 <?php $__errorArgs = ['driverName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="cth: Budi Santoso"
                                        autocomplete="off"
                                    >
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['driverName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        
                        <div class="row g-3 mb-3">
                            <div class="col-lg-8">
                                <label class="form-label fw-semibold">Barcode Dus</label>

                                <input
                                    type="text"
                                    id="loadingPackingInput"
                                    wire:model.defer="packingBarcode"
                                    class="form-control form-control-lg rounded-3 text-center fw-bold"
                                    placeholder="Scan barcode dus"
                                    autocomplete="off"
                                >
                            </div>

                            <div class="col-lg-4 d-grid align-items-end">
                                <button type="submit" class="btn btn-primary btn-lg rounded-3">
                                    <i class="bi bi-upc-scan me-1"></i>
                                    Scan Loading
                                </button>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-lg-5">
                                <div class="card border rounded-4">
                                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                        <div class="fw-bold">Target DO</div>
                                        <?php
                                            $totalLoaded   = collect($orderItems)->sum('loaded_boxes');
                                            $totalRequired = collect($orderItems)->sum('required_boxes');
                                        ?>
                                        <div class="text-end">
                                            <span class="fs-5 fw-bold text-primary"><?php echo e($totalLoaded); ?></span>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalRequired > 0): ?>
                                                <span class="text-muted small">/<?php echo e($totalRequired); ?></span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <div class="text-muted" style="font-size: .7rem; line-height: 1;">total dus</div>
                                        </div>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-sm align-middle mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="ps-3">Item</th>
                                                    <th>Progress</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <tr>
                                                        <td class="ps-3">
                                                            <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                                            <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                                        </td>

                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->required_boxes > 0): ?>
                                                            <?php
                                                                $percent = min(($item->loaded_boxes / $item->required_boxes) * 100, 100);
                                                            ?>
                                                            <td style="min-width: 150px;">
                                                                <div class="d-flex justify-content-between small mb-1">
                                                                    <span class="fw-semibold"><?php echo e($item->loaded_boxes); ?><span class="fw-normal text-muted">/<?php echo e($item->required_boxes); ?> dus</span></span>
                                                                    <span class="text-muted"><?php echo e(number_format($percent, 0)); ?>%</span>
                                                                </div>
                                                                <div class="progress" style="height: 8px;">
                                                                    <div
                                                                        class="progress-bar <?php echo e($percent >= 100 ? 'bg-success' : ''); ?>"
                                                                        style="width: <?php echo e($percent); ?>%"
                                                                    ></div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->loaded_boxes >= $item->required_boxes): ?>
                                                                    <span class="badge rounded-pill text-bg-success">OK</span>
                                                                <?php else: ?>
                                                                    <span class="badge rounded-pill text-bg-light border">WAITING</span>
                                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                            </td>
                                                        <?php else: ?>
                                                            <td style="min-width: 150px;">
                                                                <div class="fw-bold fs-5 lh-1 text-primary"><?php echo e($item->loaded_boxes); ?></div>
                                                                <small class="text-muted">dus discan</small>
                                                            </td>
                                                            <td>
                                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->loaded_boxes > 0): ?>
                                                                    <span class="badge rounded-pill text-bg-info text-white">SCANNING</span>
                                                                <?php else: ?>
                                                                    <span class="badge rounded-pill text-bg-light border">BEBAS</span>
                                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                            </td>
                                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                    </tr>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center text-muted py-4">
                                                            Item DO kosong.
                                                        </td>
                                                    </tr>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-7">
                                <div class="card border rounded-4">
                                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                        <div>
                                            <div class="fw-bold">Dus Sudah Masuk Truck</div>
                                            <small class="text-muted">Data hasil scan loading.</small>
                                        </div>

                                        <button
                                            type="button"
                                            class="btn btn-success rounded-3"
                                            onclick="confirmCompleteLoading()"
                                        >
                                            <i class="bi bi-check-circle me-1"></i>
                                            Complete Loading
                                        </button>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-sm align-middle mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="ps-3">Barcode</th>
                                                    <th>Item</th>
                                                    <th>Troli</th>
                                                    <th>Rak</th>
                                                    <th>Loaded</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $loadedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <tr>
                                                        <td class="ps-3">
                                                            <code><?php echo e($item->barcode); ?></code>
                                                            <div class="small text-muted"><?php echo e($item->box_number); ?></div>
                                                        </td>

                                                        <td>
                                                            <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                                            <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                                        </td>

                                                        <td><?php echo e($item->trolley_code ?? '-'); ?></td>
                                                        <td><?php echo e($item->rack_code ?? '-'); ?></td>

                                                        <td>
                                                            <div><?php echo e($item->loaded_by_name ?? '-'); ?></div>
                                                            <small class="text-muted">
                                                                <?php echo e($item->loaded_at ? \Carbon\Carbon::parse($item->loaded_at)->format('H:i') : '-'); ?>

                                                            </small>
                                                        </td>
                                                    </tr>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center text-muted py-4">
                                                            Belum ada dus discan ke truck.
                                                        </td>
                                                    </tr>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>

        <?php
        $__scriptKey = '556159129-0';
        ob_start();
    ?>
    <script>
        function focusLoadingInput() {
            setTimeout(() => {
                const input = document.getElementById('loadingPackingInput');

                if (input) {
                    input.value = '';
                    input.focus();
                    input.select();
                }
            }, 150);
        }

        Livewire.on('loading-modal-opened', () => {
            focusLoadingInput();
        });

        Livewire.on('loading-ready-again', () => {
            focusLoadingInput();
        });

        Livewire.on('loading-modal-closed', () => {
            focusLoadingInput();
        });

        window.confirmCompleteLoading = function () {
            Swal.fire({
                title: 'Complete loading?',
                text: 'Status DO akan berubah menjadi LOADED dan truck number disimpan.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, complete',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn btn-success rounded-3 px-4 ms-2',
                    cancelButton: 'btn btn-light border rounded-3 px-4'
                },
                buttonsStyling: false
            }).then((result) => {
                if (result.isConfirmed) {
                    $wire.completeLoading();
                }
            });
        }
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/livewire/pages/loading/index.blade.php ENDPATH**/ ?>