<div>
    <style>
        @media (max-width: 767.98px) {
            .fgd-summary .fs-2 {
                font-size: 1.5rem !important;
            }

            .fgd-actions {
                display: grid !important;
                grid-template-columns: 1fr;
                gap: .5rem;
            }

            .fgd-table th,
            .fgd-table td {
                font-size: .85rem;
                white-space: nowrap;
            }
        }
    </style>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Finish Goods Warehouse</h4>
            <div class="text-muted">
                Validasi troli dari Temporary Warehouse dan simpan ke RAK FGW.
            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success rounded-3 border-0 shadow-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="alert alert-danger rounded-3 border-0 shadow-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Scan Troli</h5>
            <div class="text-muted small">
                Scan barcode / QR troli dari Temporary Warehouse.
            </div>
        </div>

        <div class="card-body px-4 pb-4">
            <form wire:submit.prevent="scanTrolley">
                <div class="row g-3 align-items-end">
                    <div class="col-lg-10">
                        <label class="form-label fw-semibold">Barcode Troli</label>

                        <input
                            type="text"
                            id="fgwTrolleyInput"
                            wire:model.defer="trolleyBarcode"
                            class="form-control form-control-lg rounded-3"
                            placeholder="Scan barcode troli"
                            autocomplete="off"
                            autofocus
                        >
                    </div>

                    <div class="col-lg-2 d-grid">
                        <button class="btn btn-primary btn-lg rounded-3">
                            <i class="bi bi-upc-scan me-1"></i>
                            Scan
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-3 mb-4 fgd-summary">
        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Menunggu Validasi</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->waiting_validation); ?></div>
                    <div class="small text-muted">Troli dari Temporary Warehouse</div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Diterima Hari Ini</div>
                    <div class="fs-2 fw-bold"><?php echo e($summary->received_today); ?></div>
                    <div class="small text-muted">Troli masuk FGW</div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body">
                    <div class="text-muted small">Total DUS di FGW</div>
                    <div class="fs-2 fw-bold text-primary"><?php echo e(number_format($summary->total_dus_fgw)); ?></div>
                    <div class="small text-muted">Packing unit tersimpan di rak</div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-0 pt-4 px-4 pb-0">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h5 class="fw-bold mb-1">Stok per RAK FGW</h5>
                    <div class="text-muted small mb-3">Jumlah dus yang tersimpan di setiap rak saat ini.</div>
                </div>
                <div class="text-muted small">
                    Total <?php echo e(number_format($summary->total_dus_fgw)); ?> dus
                </div>
            </div>
        </div>

        <div class="card-body px-4 pb-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($dusPerRack) > 0): ?>
                <div class="row g-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $dusPerRack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $pct = $summary->total_dus_fgw > 0
                                ? ($rack->total_dus / $summary->total_dus_fgw) * 100
                                : 0;
                            $isEmpty = $rack->total_dus === 0;
                        ?>
                        <div class="col-6 col-sm-4 col-md-3 col-xl-2">
                            <div class="card border rounded-4 h-100 <?php echo e($isEmpty ? 'border-light bg-light' : 'border-primary-subtle'); ?>">
                                <div class="card-body p-3 text-center">
                                    <div class="fw-bold text-primary mb-1" style="font-size: .7rem; letter-spacing: .05em; text-transform: uppercase;">
                                        <?php echo e($rack->rack_code); ?>

                                    </div>
                                    <div class="fw-bold <?php echo e($isEmpty ? 'text-muted' : ''); ?>" style="font-size: 1.6rem; line-height: 1.1;">
                                        <?php echo e(number_format($rack->total_dus)); ?>

                                    </div>
                                    <div class="text-muted" style="font-size: .72rem;">dus</div>

                                    
                                    <div class="progress rounded-pill mt-2" style="height: 4px;">
                                        <div
                                            class="progress-bar <?php echo e($isEmpty ? 'bg-secondary' : 'bg-primary'); ?>"
                                            style="width: <?php echo e($pct); ?>%"
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="text-center text-muted py-4">
                    <i class="bi bi-grid-3x3-gap fs-1 d-block mb-2 opacity-25"></i>
                    Belum ada RAK aktif.
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
        <div class="card-header bg-white border-0 pt-4 px-4 pb-3">
            <h5 class="fw-bold mb-1">Stok Item di FGW</h5>
            <div class="text-muted small">Detail dus per item dan lokasinya di RAK.</div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 fgd-table">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Item</th>
                        <th>RAK</th>
                        <th class="text-end">Dus</th>
                        <th class="text-end">Total PCS</th>
                        <th class="text-end pe-4">Isi / Dus</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $lastItemId = null; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $stockByItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td class="ps-4">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lastItemId !== $row->item_id): ?>
                                    <div class="fw-semibold"><?php echo e($row->item_name); ?></div>
                                    <small class="text-muted"><?php echo e($row->item_code); ?></small>
                                <?php else: ?>
                                    <span class="text-muted small">↳</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php $lastItemId = $row->item_id; ?>
                            </td>
                            <td>
                                <span class="badge rounded-pill text-bg-primary-subtle border border-primary-subtle text-primary-emphasis fw-semibold">
                                    <?php echo e($row->rack_code); ?>

                                </span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->rack_name !== '—'): ?>
                                    <small class="text-muted ms-1"><?php echo e($row->rack_name); ?></small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="text-end fw-bold"><?php echo e(number_format($row->total_dus)); ?></td>
                            <td class="text-end">
                                <span class="fw-semibold"><?php echo e(number_format($row->total_pcs)); ?></span>
                                <small class="text-muted ms-1">PCS</small>
                            </td>
                            <td class="text-end pe-4 text-muted">
                                <?php echo e($row->qty_per_box ? number_format($row->qty_per_box) . ' PCS' : '—'); ?>

                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                Belum ada stok di FGW.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($stockByItem) > 0): ?>
                    <?php
                        $totalDusAll = collect($stockByItem)->sum('total_dus');
                        $totalPcsAll = collect($stockByItem)->sum('total_pcs');
                    ?>
                    <tfoot class="table-light border-top">
                        <tr>
                            <td class="ps-4 fw-bold" colspan="2">Total</td>
                            <td class="text-end fw-bold"><?php echo e(number_format($totalDusAll)); ?></td>
                            <td class="text-end fw-bold"><?php echo e(number_format($totalPcsAll)); ?> <small class="fw-normal text-muted">PCS</small></td>
                            <td class="pe-4"></td>
                        </tr>
                    </tfoot>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </table>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-header bg-white border-0 pt-4 px-4">
            <h5 class="fw-bold mb-1">Data Troli Masuk FGW</h5>
            <div class="text-muted small">
                Troli yang sudah diterima FGW beserta lokasi raknya.
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 fgd-table">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Troli</th>
                        <th>Barcode</th>
                        <th>RAK</th>
                        <th>Isi</th>
                        <th>Diterima</th>
                        <th>User</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentTrolleys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trolley): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-semibold"><?php echo e($trolley->trolley_code); ?></div>
                                <span class="badge rounded-pill text-bg-success"><?php echo e($trolley->status); ?></span>
                            </td>
                            <td><code><?php echo e($trolley->barcode); ?></code></td>
                            <td>
                                <div class="fw-semibold"><?php echo e($trolley->rack_code ?? '-'); ?></div>
                                <small class="text-muted"><?php echo e($trolley->rack_name ?? '-'); ?></small>
                            </td>
                            <td><?php echo e($trolley->total_items); ?> dus</td>
                            <td>
                                <?php echo e($trolley->received_fgw_at ? \Carbon\Carbon::parse($trolley->received_fgw_at)->format('d M Y H:i') : '-'); ?>

                            </td>
                            <td><?php echo e($trolley->received_by_name ?? '-'); ?></td>
                            <td class="text-end pe-4">
                                <button
                                    type="button"
                                    class="btn btn-sm btn-light border rounded-3"
                                    wire:click="openReceivedDetail(<?php echo e($trolley->id); ?>)"
                                >
                                    <i class="bi bi-list-check me-1"></i>
                                    Detail
                                </button>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                Belum ada troli masuk FGW.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showReceiveModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showReceiveModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Validasi Dus FGW</h5>
                        <div class="text-muted small">
                            Semua dus wajib discan ulang, lalu pilih rak.
                        </div>
                    </div>

                    <button type="button" class="btn-close" wire:click="closeModal"></button>
                </div>

                <form wire:submit.prevent="validateDus">
                    <div class="modal-body">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_success')): ?>
                            <div class="alert alert-success rounded-3 border-0">
                                <?php echo e(session('scan_success')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('scan_error')): ?>
                            <div class="alert alert-danger rounded-3 border-0">
                                <?php echo e(session('scan_error')); ?>

                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        
                        <div class="border rounded-4 p-3 mb-3 bg-light">
                            <div class="row g-3 align-items-center">
                                <div class="col-lg-6">
                                    <div class="small text-muted">Troli</div>
                                    <div class="fw-bold fs-5"><?php echo e($selectedTrolley->trolley_code ?? '-'); ?></div>
                                    <code class="small"><?php echo e($selectedTrolley->barcode ?? '-'); ?></code>
                                </div>

                                <div class="col-lg-6">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span class="fw-semibold">Progress Validasi</span>
                                        <span class="<?php echo e($totalValidated === count($trolleyItems) && count($trolleyItems) > 0 ? 'text-success fw-bold' : ''); ?>">
                                            <?php echo e($totalValidated); ?>/<?php echo e(count($trolleyItems)); ?> dus
                                        </span>
                                    </div>
                                    <div class="progress rounded-3" style="height: 12px;">
                                        <div
                                            class="progress-bar bg-success"
                                            style="width: <?php echo e(count($trolleyItems) > 0 ? ($totalValidated / count($trolleyItems)) * 100 : 0); ?>%"
                                        ></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="border rounded-4 p-4 mb-3">
                            <div class="row g-4">
                                
                                <div class="col-md-5">
                                    <label class="form-label fw-semibold mb-2">
                                        <i class="bi bi-grid-3x3-gap me-1 text-primary"></i>
                                        RAK Tujuan
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select wire:model="selectedRackId" class="form-select form-select-lg rounded-3 <?php $__errorArgs = ['selectedRackId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Pilih RAK...</option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <option value="<?php echo e($rack->id); ?>">
                                                <?php echo e($rack->rack_code); ?> — <?php echo e($rack->rack_name); ?>

                                            </option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </select>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['selectedRackId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                
                                <div class="col-md-1 d-none d-md-flex align-items-center justify-content-center">
                                    <div class="vr" style="height: 48px;"></div>
                                </div>

                                
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold mb-2">
                                        <i class="bi bi-upc-scan me-1 text-primary"></i>
                                        Barcode Dus
                                    </label>
                                    <div class="input-group input-group-lg">
                                        <input
                                            type="text"
                                            id="fgwPackingInput"
                                            wire:model.defer="packingBarcode"
                                            class="form-control rounded-start-3 text-center fw-bold"
                                            placeholder="Scan barcode dus..."
                                            autocomplete="off"
                                        >
                                        <button type="submit" class="btn btn-primary px-4 rounded-end-3">
                                            <i class="bi bi-upc-scan me-1"></i> Scan
                                        </button>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="mt-3 pt-3 border-top d-flex align-items-center justify-content-between flex-wrap gap-2">
                                <div class="text-muted small">
                                    <i class="bi bi-info-circle me-1"></i>
                                    Pilih RAK, lalu scan dus. Tiap dus bisa diarahkan ke RAK berbeda.
                                </div>
                                <button
                                    type="button"
                                    class="btn btn-success rounded-3 px-4"
                                    wire:click="completeReceiving"
                                    <?php if($totalValidated < count($trolleyItems) || count($trolleyItems) === 0): echo 'disabled'; endif; ?>
                                >
                                    <i class="bi bi-check-circle me-1"></i>
                                    Complete Receive
                                </button>
                            </div>
                        </div>

                        
                        <?php
                            $racksById = collect($racks)->keyBy('id');

                            $waitingItems = collect($trolleyItems)
                                ->filter(fn ($item) => !isset($validatedItems[$item->barcode]))
                                ->values();

                            $validatedItemRows = collect($trolleyItems)
                                ->filter(fn ($item) => isset($validatedItems[$item->barcode]))
                                ->values();

                            $sortedTrolleyItems = $waitingItems->concat($validatedItemRows);
                        ?>

                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Barcode</th>
                                        <th>Box</th>
                                        <th>Item</th>
                                        <th>SPK</th>
                                        <th>Qty</th>
                                        <th>RAK</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $sortedTrolleyItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <?php
                                            $isValidated  = isset($validatedItems[$item->barcode]);
                                            $assignedRack = $isValidated
                                                ? ($racksById[$validatedItems[$item->barcode]['rack_id']] ?? null)
                                                : null;
                                        ?>

                                        <tr class="<?php echo e($isValidated ? 'table-success' : ''); ?>">
                                            <td><code><?php echo e($item->barcode); ?></code></td>
                                            <td><?php echo e($item->box_number); ?></td>
                                            <td>
                                                <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                                <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                            </td>
                                            <td><?php echo e($item->spk_number); ?></td>
                                            <td><?php echo e(number_format($item->qty, 0, ',', '.')); ?> <?php echo e($item->uom); ?></td>
                                            <td>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($assignedRack): ?>
                                                    <span class="badge text-bg-primary rounded-pill"><?php echo e($assignedRack->rack_code); ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted small">—</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isValidated): ?>
                                                    <span class="badge text-bg-success rounded-pill">VALIDATED</span>
                                                <?php else: ?>
                                                    <span class="badge text-bg-light border rounded-pill">WAITING</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div
        class="modal fade <?php if($showReceivedDetailModal): ?> show d-block <?php endif; ?>"
        tabindex="-1"
        style="<?php if($showReceivedDetailModal): ?> background: rgba(15, 23, 42, .55); <?php else: ?> display: none; <?php endif; ?>"
    >
        <div class="modal-dialog modal-dialog-centered modal-xl modal-fullscreen-sm-down">
            <div class="modal-content border-0 shadow rounded-4">
                <div class="modal-header border-0 pb-0">
                    <div>
                        <h5 class="modal-title fw-bold">Detail Troli Masuk FGW</h5>
                        <div class="text-muted small">
                            Detail barang yang sudah diterima FGW.
                        </div>
                    </div>

                    <button type="button" class="btn-close" wire:click="closeReceivedDetail"></button>
                </div>

                <div class="modal-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($receivedDetailTrolley): ?>
                        <div class="border rounded-4 p-3 mb-3 bg-light">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="small text-muted">Troli</div>
                                    <div class="fw-bold"><?php echo e($receivedDetailTrolley->trolley_code); ?></div>
                                    <code><?php echo e($receivedDetailTrolley->barcode); ?></code>
                                </div>
                                <div class="col-md-3">
                                    <div class="small text-muted">RAK</div>
                                    <div class="fw-bold"><?php echo e($receivedDetailTrolley->rack_code ?? '-'); ?></div>
                                    <small><?php echo e($receivedDetailTrolley->rack_name ?? '-'); ?></small>
                                </div>
                                <div class="col-md-3">
                                    <div class="small text-muted">Diterima</div>
                                    <div>
                                        <?php echo e($receivedDetailTrolley->received_fgw_at ? \Carbon\Carbon::parse($receivedDetailTrolley->received_fgw_at)->format('d M Y H:i') : '-'); ?>

                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="small text-muted">Total Dus</div>
                                    <div class="fw-bold"><?php echo e($receivedDetailTrolley->total_items); ?> dus</div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3">Barcode</th>
                                    <th>Box</th>
                                    <th>Item</th>
                                    <th>SPK</th>
                                    <th>Qty</th>
                                    <th>Lokasi RAK</th>
                                    <th>Status</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $lastRack = null; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $receivedDetailItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->rack_code !== $lastRack): ?>
                                        <tr class="table-primary">
                                            <td colspan="7" class="ps-3 py-2">
                                                <i class="bi bi-grid-3x3-gap me-1"></i>
                                                <span class="fw-semibold">RAK <?php echo e($item->rack_code ?? '—'); ?></span>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->rack_name): ?>
                                                    <span class="text-muted small ms-1">— <?php echo e($item->rack_name); ?></span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php $lastRack = $item->rack_code; ?>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <tr>
                                        <td class="ps-3"><code><?php echo e($item->barcode); ?></code></td>
                                        <td><?php echo e($item->box_number); ?></td>
                                        <td>
                                            <div class="fw-semibold"><?php echo e($item->item_name); ?></div>
                                            <small class="text-muted"><?php echo e($item->item_code); ?></small>
                                        </td>
                                        <td><?php echo e($item->spk_number); ?></td>
                                        <td><?php echo e(number_format($item->qty, 0, ',', '.')); ?> <?php echo e($item->uom); ?></td>
                                        <td>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->rack_code): ?>
                                                <span class="badge text-bg-primary rounded-pill"><?php echo e($item->rack_code); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted small">—</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge rounded-pill text-bg-success"><?php echo e($item->status); ?></span>
                                        </td>
                                    </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-5">
                                            <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                            Detail kosong.
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="modal-footer border-0 pt-0">
                    <button type="button" wire:click="closeReceivedDetail" class="btn btn-light border rounded-3 px-4">
                        Tutup
                    </button>
                </div>
            </div>
        </div>
    </div>

        <?php
        $__scriptKey = '1373868105-0';
        ob_start();
    ?>
    <script>
        function focusFgwPacking() {
            setTimeout(() => {
                const input = document.getElementById('fgwPackingInput');
                if (input) {
                    input.value = '';
                    input.focus();
                    input.select();
                }
            }, 150);
        }

        function focusFgwTrolley() {
            setTimeout(() => {
                const input = document.getElementById('fgwTrolleyInput');
                if (input) {
                    input.value = '';
                    input.focus();
                    input.select();
                }
            }, 150);
        }

        Livewire.on('fgw-scan-opened', () => {
            focusFgwPacking();
        });

        Livewire.on('fgw-ready-again', () => {
            focusFgwPacking();
        });

        Livewire.on('fgw-modal-closed', () => {
            focusFgwTrolley();
        });

        Livewire.on('fgw-focus-trolley', () => {
            focusFgwTrolley();
        });
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH /Users/bella/yujang/project/camiloplas-logistic/resources/views/livewire/pages/fgd/index.blade.php ENDPATH**/ ?>